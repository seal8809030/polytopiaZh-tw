<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'xmldb', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   xmldb
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actual'] = '放在此資料表後：';
$string['aftertable'] = '放在此資料表後：';
$string['back'] = '返回';
$string['backtomainview'] = '返回主視圖';
$string['binaryincorrectlength'] = '二進位資料欄位的長度不正確';
$string['cannotuseidfield'] = '不能插入"id" 欄位。因為它是一個自動編號的欄位';
$string['change'] = '更改';
$string['charincorrectlength'] = '字元欄位的長度不正確';
$string['checkbigints'] = '檢查長整數(Bigints)';
$string['check_bigints'] = '尋找不正確的資料庫整數';
$string['checkdefaults'] = '檢查預設值';
$string['check_defaults'] = '找不到一致的預設值';
$string['checkforeignkeys'] = '檢查外鍵(foreign keys)';
$string['check_foreign_keys'] = '搜尋無效的(foreign keys)';
$string['checkindexes'] = '檢查索引';
$string['check_indexes'] = '尋找遺失的資料庫索引';
$string['completelogbelow'] = '(查看下面搜尋的完整日誌)';
$string['confirmcheckbigints'] = '本功能將在您的Moodle伺服器搜尋<a href="http://tracker.moodle.org/browse/MDL-11038">潛在的整數欄位錯誤</a>，自動產生(而不是執行！)正確定義您資料庫中的整數的SQL語法。<br /><br />
您可以複製這些語法到您習慣使用的SQL介面中安全的執行(不要忘記在此之前備份您的資料庫)。<br /><br />
在搜尋之前，強烈建議使用您的Moodle發行版本（1.8、1.9、2.x……）的最新版(帶+的版本)。<br /><br />
此功能不會對資料庫做任何寫入操作(只是讀取)，所以任何時候執行它都是安全的。';
$string['confirmcheckdefaults'] = '本功能將在您的Moodle伺服器搜尋<a href="http://tracker.moodle.org/browse/MDL-11038">潛在的整數欄位錯誤</a>，自動產生(而不是執行！)正確定義您資料庫中的整數的SQL語法。<br /><br />
您可以複製這些語法到您習慣使用的SQL介面中安全的執行(不要忘記在此之前備份您的資料庫)。<br /><br />
在搜尋之前，強烈建議使用您的Moodle發行版本（1.8、1.9、2.x……）的最新版(帶+的版本)。<br /><br />
此功能不會對資料庫做任何寫入操作(只是讀取)，所以任何時候執行它都是安全的。';
$string['confirmcheckforeignkeys'] = '這個功能會搜尋您的Moodle伺服器上可能遺失的索引資料，並自動產生(但不會執行)所需的SQL指令以更新。產生後，您可以將它們複製到您的SQL客戶端中執行它們。<br /><br />我們建議您在搜尋遺失的索引前，確定是使用Moodle(1.8、1.9、2.x等）的最新版本(+)。<br /><br />這個功能並不在資料庫伺服器上執行任何操作(只讀取而已)，因此隨時都可以安全地執行。';
$string['confirmcheckindexes'] = '這個功能會搜尋您的Moodle伺服器上可能遺失的索引資料，並自動產生(但不會執行)所需的SQL指令以更新。產生後，您可以將它們複製到您的SQL客戶端中執行它們。<br /><br />我們建議您在搜尋遺失的索引前，確定是使用Moodle(1.8、1.9、2.x等）的最新版本(+)。<br /><br />這個功能並不在資料庫伺服器上執行任何操作(只讀取而已)，因此隨時都可以安全地執行。';
$string['confirmdeletefield'] = '您是否非常確信要刪除此欄位：';
$string['confirmdeleteindex'] = '您是否非常確信要刪除此索引：';
$string['confirmdeletekey'] = '您是否非常確信要刪除此鍵值：';
$string['confirmdeletetable'] = '您是否非常確信要刪除此表：';
$string['confirmdeletexmlfile'] = '您是否非常確信要刪除此文件：';
$string['confirmrevertchanges'] = '您是否非常確信要恢復對此所做的改變：';
$string['create'] = '建立';
$string['createtable'] = '建立資料表：';
$string['defaultincorrect'] = '不正確的預設值';
$string['delete'] = '刪除';
$string['delete_field'] = '刪除欄位';
$string['delete_index'] = '刪除索引';
$string['delete_key'] = '刪除鍵值';
$string['delete_table'] = '刪除資料表';
$string['delete_xml_file'] = '刪除XML文件';
$string['doc'] = '文件';
$string['docindex'] = '文件索引：';
$string['documentationintro'] = '本文件從XMLDB資料庫定義中直接產生。他只有英文版。';
$string['down'] = '向下';
$string['duplicate'] = '複製';
$string['duplicatefieldname'] = '已存在一個同名的欄位';
$string['duplicatekeyname'] = '已經存在相同名稱的鍵';
$string['edit'] = '編輯';
$string['edit_field'] = '編輯欄位';
$string['edit_field_save'] = '儲存欄位';
$string['edit_index'] = '編輯索引';
$string['edit_index_save'] = '儲存索引';
$string['edit_key'] = '編輯鍵值';
$string['edit_key_save'] = '儲存鍵值';
$string['edit_table'] = '編輯資料表';
$string['edit_table_save'] = '儲存資料表';
$string['edit_xml_file'] = '編輯XML文件';
$string['enumvaluesincorrect'] = '列舉型別(enum)欄位的值不正確';
$string['expected'] = '預期';
$string['extensionrequired'] = '抱歉-此動作需要呼叫php擴充"{$a}"。如果您要使用此特性，請安裝此擴充。';
$string['field'] = '欄位';
$string['fieldnameempty'] = '空的欄位名';
$string['fields'] = '欄位';
$string['fieldsnotintable'] = '欄位在資料表中不存在';
$string['fieldsusedinkey'] = '此欄位被當作主鍵。';
$string['filenotwriteable'] = '檔案不可寫';
$string['fkviolationdetails'] = '資料表{$a->tablename}的{$a->numrows}行數據中，有{$a->numviolations}行的外鍵{$a->keyname}是無效的。';
$string['float2numbernote'] = '注意：雖然XMLDB完全支援"float"欄位，但仍然建議用number"欄位代替它。';
$string['floatincorrectdecimals'] = '浮點數欄位的小數位數不正確';
$string['floatincorrectlength'] = '浮點數欄位的長度不正確';
$string['generate_all_documentation'] = '所有文件';
$string['generate_documentation'] = '文件';
$string['gotolastused'] = '移至上次使用的檔案';
$string['incorrectfieldname'] = '不正確的欄位名稱';
$string['index'] = 'Index';
$string['indexes'] = '索引';
$string['integerincorrectlength'] = '整數欄位的長度不正確';
$string['key'] = 'Key';
$string['keys'] = '鍵值';
$string['listreservedwords'] = '保留字清單<br/>（用來保持<a href="http://docs.moodle.org/en/XMLDB_reserved_words" target="_blank">XMLDB保留字</a>的更新)';
$string['load'] = '載入';
$string['main_view'] = '主視圖';
$string['masterprimaryuniqueordernomatch'] = '您的外鍵中的所有欄位的定義順序，都必須與他們在對應的表中的UNIQUE KEY中的定義順序相同。';
$string['missing'] = '遺失的';
$string['missingindexes'] = '找到了遺失的索引';
$string['mustselectonefield'] = '您必須選擇一個欄位來查看與欄位相關的動作！';
$string['mustselectoneindex'] = '您必須選擇一個索引來查看與索引相關的動作！';
$string['mustselectonekey'] = '您必須選擇一個鍵值來查看與鍵值相關的動作！';
$string['mysqlextracheckbigints'] = '如使用MySQL資料庫，它還將尋找不正確的帶正負號big int。';
$string['newfield'] = '建立新欄位';
$string['newindex'] = '建立新索引';
$string['newkey'] = '建立新鍵值';
$string['newtable'] = '建立新資料表';
$string['newtablefrommysql'] = '從MySQL建新資料表';
$string['new_table_from_mysql'] = '從MySQL建新資料表';
$string['nomasterprimaryuniquefound'] = '您的外鍵對應的欄位必須是應對中的主鍵或唯一鍵。注意，欄位只有UNIQUE INDEX是不夠的。';
$string['nomissingindexesfound'] = '沒有找到遺失的索引，您的資料庫不需要更多操作。';
$string['noviolatedforeignkeysfound'] = '為發現無效的外鍵';
$string['nowrongdefaultsfound'] = '沒有發現不一致的預設值。';
$string['nowrongintsfound'] = '沒有發現整數錯誤。';
$string['numberincorrectdecimals'] = '數字欄位的小數位數不正確';
$string['numberincorrectlength'] = '數字欄位的長度不正確';
$string['pendingchanges'] = '注意：您已經修改了此文件。它隨時都可能被儲存。';
$string['pendingchangescannotbesaved'] = '此檔案有修改，但無法儲存！請確認Web伺服器對目錄和他裡面的install.xml檔案都有寫入權限。';
$string['pendingchangescannotbesavedreload'] = '此檔案有修改，但不能儲存！請確認Web 服務器對目錄和它裡面的install.xml檔案都有寫入權限。然後重新讀取此頁面，您就能儲存這些變更了。';
$string['reserved'] = '保留';
$string['reservedwords'] = '保留字';
$string['revert'] = '回復';
$string['revert_changes'] = '回復變更';
$string['save'] = '儲存';
$string['searchresults'] = '搜尋結果';
$string['selectaction'] = '選擇動作：';
$string['selectdb'] = '選擇資料庫：';
$string['selectfieldkeyindex'] = '選擇欄位 / 鍵 / 索引：';
$string['selectonecommand'] = '為了查看PHP程式碼，請在列表中選擇一個動作';
$string['selectonefieldkeyindex'] = '為了查看PHP程式碼，請在列表中選擇一個欄位/鍵/索引';
$string['selecttable'] = '選擇資料表：';
$string['table'] = '資料表';
$string['tables'] = '資料表';
$string['textincorrectlength'] = '文字欄位的長度不正確';
$string['unload'] = '卸除';
$string['up'] = '向上';
$string['view'] = '檢視';
$string['viewedited'] = '檢視';
$string['vieworiginal'] = '檢視';
$string['viewphpcode'] = '檢視PHP程式碼';
$string['view_reserved_words'] = '檢視保留字';
$string['viewsqlcode'] = '檢視SQL語法';
$string['view_structure_php'] = '檢視';
$string['view_structure_sql'] = '檢視';
$string['view_table_php'] = '檢視';
$string['view_table_sql'] = '檢視';
$string['viewxml'] = 'XML';
$string['violatedforeignkeys'] = '無效的外鍵';
$string['violatedforeignkeysfound'] = '發現無效的外鍵';
$string['violations'] = '違反';
$string['wrong'] = '錯誤';
$string['wrongdefaults'] = '發現錯誤的預設值';
$string['wrongints'] = '發現錯誤的整數資料';
$string['wronglengthforenum'] = '列舉(enum)欄位的長度不正確';
$string['wrongreservedwords'] = '目前使用的保留字<br/>（如果資料表名稱使用{$CFG->prefix}，就不用留意這個問題）';
$string['yesmissingindexesfound'] = '已經在您的資料庫中找到了一些遺失的索引資料。下面列出了關於它們的詳細情況以及建立它們的命令，您可以在SQL客戶端中執行它們。<br /><br />完成這個操作後，建議您重新執行這個工具，以確認沒有更多遺失的索引資料。';
$string['yeswrongdefaultsfound'] = '在資料庫中已經發現了不一致的預設值。以下是詳細資料，需要執行SQL指令來修正 (注意！請先備份資料庫)。<br /><br />我們強烈建議您在修改完成後，重新用此工具進行檢查確認沒有其他錯誤。';
$string['yeswrongintsfound'] = '在資料庫中已經發現了不一致的預設值。以下是詳細資料，需要執行SQL指令來修正 (注意！請先備份資料庫)。<br /><br />我們強烈建議您在修改完成後，重新用此工具進行檢查確認沒有其他錯誤。';
