<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'completion', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   completion
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['achievinggrade'] = '完成的成績';
$string['activities'] = '活動';
$string['activitiescompleted'] = '活動已完成';
$string['activitycompletion'] = '活動完成度';
$string['addcourseprerequisite'] = '先修課程';
$string['afterspecifieddate'] = '指定日期後';
$string['aggregationmethod'] = '聚合方法';
$string['all'] = '全部';
$string['any'] = '任意';
$string['approval'] = '認可';
$string['badautocompletion'] = '當您選擇了自動完成時，您還必須激活至少一個前提（在下面）。';
$string['completedunlocked'] = '完成選項已解鎖';
$string['completedunlockedtext'] = '保存修改後，所有學生的完成狀態都會被刪除。如果您改變了主意，就不要保存此表單。';
$string['completedwarning'] = '完成選項已鎖定';
$string['completedwarningtext'] = '一個或多個學生（{$a}）已經標記這項活動爲完成。改變完成選項會刪除他們的完成狀態記錄，有可能導致混亂。因此，這些選項已被加鎖。除非絕對必要，請不要解鎖。';
$string['completion'] = '進度跟蹤';
$string['completion-alt-auto-enabled'] = '系統根據條件設置標記此項是否完成';
$string['completion-alt-auto-fail'] = '已完成（成績未達到通過綫）';
$string['completion-alt-auto-n'] = '未完成';
$string['completion-alt-auto-pass'] = '已完成（成績達到通過綫）';
$string['completion-alt-auto-y'] = '已完成';
$string['completion-alt-manual-enabled'] = '學生可以手工標記此項爲完成';
$string['completion-alt-manual-n'] = '未完成；勾選以標記爲完成';
$string['completion-alt-manual-y'] = '已完成；勾選以標記爲未完成';
$string['completion_automatic'] = '當條件都滿足時，將活動標爲完成';
$string['completiondisabled'] = '禁用，不在活動設置頁面顯示';
$string['completionenabled'] = '啓用，通過完成狀態和活動設置來控制';
$string['completionexpected'] = '預期完成時間';
$string['completionexpected_help'] = '此選項設置此活動預期的完成日期。這個日期只顯示在活動完成報告中，不會顯示給學生。';
$string['completion_help'] = '如果啓用，將基於給定的條件，人工或自動跟蹤活動的完成狀態。如需要，可以設置多個條件，那麼只有所有條件都滿足時活動才被看作已完成。

在課程頁面，當活動已完成時，活動名後面會有一個標記。';
$string['completionicons'] = '完成狀態標記框';
$string['completionicons_help'] = '當活動已完成時，活動名後面會有一個標記。

如果顯示的是一個圓點標記，那麼當您覺得已經完成此活動時，就勾選它。（如果您改變了主意，就再點它一下來取消勾選。）此動作並不是必須做的，它只是跟蹤您課程學習進度的一個簡單方法。

如果顯示的是一個空的標記框，那麼當你達到了教師爲此活動設定的條件時，它會自動被標記。';
$string['completion_manual'] = '學生可以手工設置此活動爲完成';
$string['completionmenuitem'] = '學習進度';
$string['completion_none'] = '不標示活動完成狀態';
$string['completionnotenabled'] = '進度追蹤功能尚未啟用';
$string['completionnotenabledforcourse'] = '本課程尚未開啟進度追蹤功能';
$string['completionnotenabledforsite'] = '本站尚未開啟進度追蹤功能';
$string['completiononunenrolment'] = '撤銷選課時記爲已完成';
$string['completionsettingslocked'] = '完成設置已鎖定';
$string['completionstartonenrol'] = '選課時開始跟蹤進度';
$string['completionstartonenrolhelp'] = '在成功選課後開始跟蹤學生在課程中的學習進度';
$string['completion-title-manual-n'] = '標記爲完成';
$string['completion-title-manual-y'] = '標記爲未完成';
$string['completionusegrade'] = '需要有成績';
$string['completionusegrade_desc'] = '學生必須獲得成績才能完成此活動';
$string['completionusegrade_help'] = '如果激活，此活動在學生獲得成績時被標記爲完成。如果活動設置了通過綫，那麼會顯示通過或沒通過圖標。';
$string['completionview'] = '需要完成瀏覽';
$string['completionview_desc'] = '學生必須瀏覽此活動，才能完成它';
$string['configenablecompletion'] = '啓用後，您就可以在課程級別使用學習進度跟蹤功能。';
$string['confirmselfcompletion'] = '確認自己完成';
$string['coursealreadycompleted'] = '您已經完成了這門課程';
$string['coursecomplete'] = '課程完成';
$string['coursecompleted'] = '課程已完成';
$string['coursegrade'] = '課程成績';
$string['courseprerequisites'] = '先修課程';
$string['coursesavailable'] = '可用的課程';
$string['coursesavailableexplaination'] = '<i>必須爲課程設置完成指標，才能出現在此列表中</i>';
$string['criteria'] = '指標';
$string['criteriagroup'] = '指標組';
$string['criteriarequiredall'] = '下列所有指標都是必需的';
$string['criteriarequiredany'] = '必須滿足下列任一指標';
$string['csvdownload'] = '以電子表格格式（UTF-8.csv）下載';
$string['datepassed'] = '通過日期';
$string['days'] = '天數';
$string['daysafterenrolment'] = '選課後天數';
$string['deletecoursecompletiondata'] = '刪除課程完成數據';
$string['durationafterenrolment'] = '選課後期限';
$string['editcoursecompletionsettings'] = '編輯課程進度跟蹤設置';
$string['enablecompletion'] = '啓用學習進度跟蹤';
$string['enrolmentduration'] = '剩余天數';
$string['err_noactivities'] = '沒有任何活動啓用了完成信息，所以什麼都不能顯示。您可以通過修改活動設置來啓用完成信息。';
$string['err_nocourses'] = '沒有其它課程啓用課程進度跟蹤功能，所以沒有可顯示的。您可以在課程設置中啓用課程進度跟蹤功能。';
$string['err_nograde'] = '此課程還尚未設定及格分數線。要想起用這種策略，您必須先為此課程建立及格數線。';
$string['err_noroles'] = '課程中沒有任何角色有“moodle/course:markcomplete”權限。您可以通過給角色分配此權限來啓用這種指標類型。';
$string['err_nousers'] = '課程或小組中沒有可以顯示完成信息的學生。（缺省情況下，只顯示學生的完成信息，所以沒有學生的話，您就會看到這個錯誤。管理員可以修改此選項。）';
$string['err_settingslocked'] = '一個或多個學生已經完成了某指標，所以此設置被加鎖。解鎖完成指標設置將刪除全部已有的用戶數據，有可能造成困擾。';
$string['err_system'] = '進度跟蹤系統內部發生錯誤。（系統管理員可以激活調試信息來查看更多細節。）';
$string['excelcsvdownload'] = '用Excel兼容格式（.csv）下載';
$string['fraction'] = '分數';
$string['inprogress'] = '處理中';
$string['manualcompletionby'] = '可手動標記完成';
$string['manualselfcompletion'] = '手動標記自己完成';
$string['markcomplete'] = '標爲完成';
$string['markedcompleteby'] = '由{$a}標記爲完成';
$string['markingyourselfcomplete'] = '標記您自己爲完成';
$string['moredetails'] = '更多細節';
$string['nocriteriaset'] = '本課程尚未設定完成條件';
$string['notenroled'] = '您不是以學生身份在本課程選課的。';
$string['notyetstarted'] = '還未開始';
$string['overallcriteriaaggregation'] = '整體指標類型聚合';
$string['passinggrade'] = '通過綫';
$string['pending'] = '等待中';
$string['periodpostenrolment'] = '入學後的階段';
$string['prerequisites'] = '先決條件';
$string['prerequisitescompleted'] = '完成先決條件';
$string['progress'] = '學生進度';
$string['progress-title'] = '{$a->user}, {$a->activity}: {$a->state} {$a->date}';
$string['recognitionofpriorlearning'] = '確認先修課程';
$string['remainingenroledfortime'] = '在指定時間段內保持選課';
$string['remainingenroleduntildate'] = '在指定日期前保持選課';
$string['reportpage'] = '顯示從{$a->from}到{$a->to}的使用者（共{$a->total}人）。';
$string['requiredcriteria'] = '必備指標';
$string['restoringcompletiondata'] = '寫入進度資料中';
$string['saved'] = '保存';
$string['seedetails'] = '查看細節';
$string['self'] = '自己';
$string['selfcompletion'] = '自己完成';
$string['showinguser'] = '顯示用戶';
$string['unenrolingfromcourse'] = '從課程註銷選課';
$string['unenrolment'] = '註銷選課';
$string['unit'] = '單元';
$string['unlockcompletion'] = '解鎖完成選項';
$string['unlockcompletiondelete'] = '解鎖完成選項並刪除用戶完成數據';
$string['usealternateselector'] = '使用替代的課程選擇棄';
$string['viewcoursereport'] = '查看課程報告';
$string['viewingactivity'] = '查看 {$a}';
$string['writingcompletiondata'] = '寫入進度資料';
$string['xdays'] = '{$a}天';
$string['yourprogress'] = '您的進度';
