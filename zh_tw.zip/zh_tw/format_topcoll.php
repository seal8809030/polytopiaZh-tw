<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'format_topcoll', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   format_topcoll
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['formattopcoll'] = '主題開闔格式';
$string['nametopcoll'] = '主題開闔格式';
$string['pluginname'] = '主題開闔格式';
$string['section0name'] = '一般';
$string['sectionname'] = '單元';
$string['setcolour_help'] = '包括課程內的有關顏色的設定';
$string['setlayout'] = '設定版面編排';
$string['setlayout_default'] = '預設';
$string['setlayoutelements_help'] = '您想用顯示多少有關切換／單元的資料';
$string['setlayout_help'] = '包括課程內的格式版面的設定';
$string['setlayout_no_section_no'] = '沒有單元號碼';
$string['setlayout_no_toggle_section_x'] = '沒有切換單元x';
$string['setlayout_no_toggle_section_x_section_no'] = '沒有切換單元x 及單元號碼';
$string['setlayout_no_toggle_word'] = '沒有切換字眼';
$string['setlayout_no_toggle_word_toggle_section_x'] = '沒有切換字眼及切換單元x';
$string['setlayout_no_toggle_word_toggle_section_x_section_no'] = '沒有切換字眼，切換單元x 及單元號碼';
$string['setlayoutstructuretopic'] = '主題';
$string['setlayoutstructureweek'] = '星期';
$string['settogglebackgroundcolour'] = '切換背景';
$string['settogglebackgroundhovercolour'] = '切換的背景光標';
$string['settoggleforegroundcolour'] = '切換前景';
$string['settoggleforegroundcolour_help'] = '設定切換中的文字顏色';
$string['topcolltoggle'] = '切換';
