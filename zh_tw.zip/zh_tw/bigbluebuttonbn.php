<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'bigbluebuttonbn', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   bigbluebuttonbn
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['bbbduetimeoverstartingtime'] = '這一活動的到期時間必須早於開始時間';
$string['bbbdurationwarning'] = '這一次會議的最長時間是 %duration%分鐘';
$string['bbbfinished'] = '這一活動已經結束';
$string['bbbinprocess'] = '這一活動正在進行中';
$string['bbbnorecordings'] = '這裡還沒有錄影檔，請稍後再來';
$string['bbbnotavailableyet'] = '抱歉，這一視訊會議還不能使用';
$string['bbbrecordwarning'] = '這一次會議可以被錄製';
$string['bbburl'] = '你的視訊會議伺服器的網址必須以 /bigbluebutton/做結尾。(這一預設的網址是blindside 網路所提供視訊會議伺服器，它可供你進行測試)';
$string['bigbluebuttonbn'] = 'BigBlueButton視訊會議';
$string['bigbluebuttonbn:addinstance'] = '新增會議';
$string['bigbluebuttonbn:join'] = '參加會議';
$string['bigbluebuttonbn:moderate'] = '主持會議';
$string['bigbluebuttonbnSalt'] = '視訊會議共用密碼';
$string['bigbluebuttonbnUrl'] = '視訊會議伺服器網址';
$string['bigbluebuttonbnWait'] = '用戶必須等待';
$string['configsecuritysalt'] = '你的視訊會議伺服器的密碼。(這預設的密碼是由 Blindside 網路公司所提供的網路視訊會議伺服器專用的密碼，你可用它來進行測試)';
$string['event_activity_created'] = 'BigBlueButtonBN活動已建立';
$string['event_activity_deleted'] = 'BigBlueButtonBN活動已刪除';
$string['event_activity_modified'] = 'BigBlueButtonBN已修改';
$string['event_activity_viewed'] = 'BigBlueButtonBN已檢視';
$string['event_activity_viewed_all'] = 'BigBlueButtonBN活動管理已檢視';
$string['event_meeting_created'] = 'BigBlueButtonBN會議已建立';
$string['event_meeting_ended'] = '已強制結束同步視訊會議';
$string['event_meeting_joined'] = '已加入同步視訊會議';
$string['event_meeting_left'] = '已離開同步視訊會議';
$string['general_error_unable_connect'] = '無法連結。請檢查視訊會議伺服器的網址，並檢查該伺服器是否正在運作中';
$string['index_confirm_end'] = '你希望結束這虛擬教室嗎？';
$string['index_disabled'] = '關閉';
$string['index_enabled'] = '啟用';
$string['index_ending'] = '虛擬教室正在結束...請等待';
$string['index_error_checksum'] = '檢查時發生錯誤。請確定你輸入的添加碼';
$string['index_error_forciblyended'] = '無法加入這一會議，因為已經被手動地結束';
$string['index_error_unable_display'] = '無法顯示這視訊會議。請檢查視訊會議伺服器的網址，並檢查這伺服器是否正在運作中';
$string['index_heading'] = '同步視訊會議室';
$string['index_heading_actions'] = '行動';
$string['index_heading_group'] = '群組';
$string['index_heading_moderator'] = '主持人';
$string['index_heading_name'] = '房間';
$string['index_heading_recording'] = '錄影紀錄';
$string['index_heading_users'] = '用戶';
$string['index_heading_viewer'] = '觀眾';
$string['index_running'] = '進行中';
$string['index_warning_adding_meeting'] = '無法指派一個新會議編號';
$string['mod_form_block_general'] = '一般設定';
$string['mod_form_block_participants'] = '參與人員';
$string['mod_form_block_record'] = '錄製的設定';
$string['mod_form_block_schedule'] = '會議的時間安排';
$string['mod_form_field_allmoderators'] = '允許所有的參與者成為主持人';
$string['mod_form_field_availabledate'] = '可參加時間';
$string['mod_form_field_description'] = '錄製的會議的說明';
$string['mod_form_field_description_help'] = '一個錄製檔內容的簡短說明，它會被顯示在錄製檔清單上。它可以就每一次會議內容加以更改。';
$string['mod_form_field_duedate'] = '關閉的時間';
$string['mod_form_field_duration'] = '長度';
$string['mod_form_field_duration_help'] = '設定會議時間長度可讓會議錄音結束前會議持續運作。';
$string['mod_form_field_name'] = '虛擬教室名稱';
$string['mod_form_field_newwindow'] = '在新視窗開啟視訊會議';
$string['mod_form_field_participant_add'] = '增加參與人員';
$string['mod_form_field_participant_bbb_role_moderator'] = '主持人';
$string['mod_form_field_participant_bbb_role_viewer'] = '觀眾';
$string['mod_form_field_participant_list'] = '參加人員名單';
$string['mod_form_field_participant_list_action_add'] = '加入';
$string['mod_form_field_participant_list_action_remove'] = '移除';
$string['mod_form_field_participant_list_text_as'] = '為';
$string['mod_form_field_participant_list_type_all'] = '課程全部人員';
$string['mod_form_field_participant_list_type_role'] = '角色';
$string['mod_form_field_participant_list_type_user'] = '用戶';
$string['mod_form_field_record'] = '錄影';
$string['mod_form_field_userlimit'] = '用戶限制';
$string['mod_form_field_userlimit_help'] = '一個會議最高可多少人參加。若限制設為0，表示無人數限制。';
$string['mod_form_field_voicebridge'] = '電話連線代號[####]';
$string['mod_form_field_voicebridge_help'] = '可參加"人聲會議"的人數。';
$string['mod_form_field_wait'] = '觀眾必須等待，直到一個主持人加入';
$string['mod_form_field_welcome'] = '歡迎訊息';
$string['mod_form_field_welcome_default'] = '<br>歡迎來到<b>%%CONFNAME%%</b>!<br><br>要了解此視訊會議系統如何運作，請看我們的 <a href="event:http://www.bigbluebutton.org/content/videos"><u>教學影片</u></a>。<br><br>To join the audio bridge click the headset icon (upper-left hand corner). <b>Please use a headset to avoid causing noise for others.</b>';
$string['mod_form_field_welcome_help'] = '取代視訊會議伺服器預設的歡迎詞。這歡迎詞可以包括一些變數，如 (%%CONFNAME%%, %%DIALNUM%%, %%CONFNUM%%)。它們在顯示時會自動被替換掉，且也可加上html 標籤，像是 <b>...</b> 或 <i></i>';
$string['modulename'] = '同步視訊會議';
$string['modulename_help'] = 'BigBlueButtonBN視訊會議lets you create from within Moodle links to real-time on-line classrooms using BigBlueButton, an open source web conferencing system for distance education.

Using BigBlueButtonBN you can specify for the title, description, calendar entry (which gives a date range for joining the session), groups, and details about the recording of the on-line session.

To view later recordings, add a RecordingsBN resource to this course.';
$string['modulenameplural'] = '同步視訊會議';
$string['pluginadministration'] = '同步視訊會議管理';
$string['pluginname'] = '同步視訊會議';
$string['serverhost'] = '伺服器名稱';
$string['view_error_create'] = '這視訊會議伺服器回應一個錯誤訊息，這會議不能夠建立。';
$string['view_error_max_concurrent'] = '已經達到可同時參與會議的最高人數';
$string['view_error_no_group'] = '這兒沒有配置群組。請在加入會議之前設定群組。';
$string['view_error_no_group_student'] = '你沒有加入一個群組，請聯絡你的教師或管理員。';
$string['view_error_no_group_teacher'] = '這裡還沒有配置群組。請設定群組或聯絡管理員。';
$string['view_error_unable_join'] = '無法加入會議。請檢查BigBlueButton 伺服器的網址，並檢查它是否在運作中。';
$string['view_error_unable_join_student'] = '無法連結到視訊會議伺服器。請聯絡你的教師或網站管理員。';
$string['view_error_unable_join_teacher'] = '無法連結到視訊會議伺服器。請聯絡網站管理員。';
$string['view_error_userlimit_reached'] = '已經達到這會議的最大人數限制';
$string['view_groups_selection'] = '選擇你要加入的群組，並加以確認';
$string['view_groups_selection_join'] = '參加';
$string['view_login_moderator'] = '登入為主持人...';
$string['view_login_viewer'] = '登入為觀眾...';
$string['view_noguests'] = '同步視訊會議未開放給訪客參加';
$string['view_nojoin'] = '你不具備有能加入這議程的角色';
$string['view_recording_list_actionbar'] = '工具';
$string['view_recording_list_actionbar_delete'] = '刪除';
$string['view_recording_list_actionbar_hide'] = '隱藏';
$string['view_recording_list_actionbar_show'] = '顯示';
$string['view_recording_list_activity'] = '活動';
$string['view_recording_list_course'] = '課程';
$string['view_recording_list_date'] = '時間';
$string['view_recording_list_description'] = '說明';
$string['view_recording_list_duration'] = '長度';
$string['view_recording_list_recording'] = '錄影紀錄';
$string['view_wait'] = '虛擬課程尚未開始，正等候主持人中...';
