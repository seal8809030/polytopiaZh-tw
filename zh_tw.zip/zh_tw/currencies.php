<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'currencies', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   currencies
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['AED'] = '阿拉伯聯合大公國迪爾汗 / 迪拉姆';
$string['AFA'] = '阿富汗阿富汗尼 (被AFN取代)';
$string['ALL'] = '阿爾巴尼亞列克';
$string['ANG'] = '荷屬安的列斯盾 / 弗羅林';
$string['AON'] = '安哥拉寬扎';
$string['ARA'] = '奧斯特拉';
$string['AUD'] = '澳元';
$string['AWG'] = '阿魯巴弗羅林 / 基爾德';
$string['BBD'] = '巴貝多元';
$string['BDT'] = '孟加拉塔卡';
$string['BGL'] = '保加利亞列弗 (1999年7月5日被BGN取代)';
$string['BHD'] = '巴林第納爾';
$string['BIF'] = '蒲隆地法郎';
$string['BMD'] = '百慕達元';
$string['BND'] = '汶萊元';
$string['BOB'] = '玻利維亞幣';
$string['BRR'] = '巴西克魯塞羅裡亞爾';
$string['BSD'] = '巴哈馬元';
$string['BTN'] = '不丹努扎姆（也用印度盧比(INR)）';
$string['BUK'] = '緬甸元';
$string['BWP'] = '波札那普拉';
$string['BZD'] = '貝里斯元';
$string['CAD'] = '加拿大元';
$string['CDZ'] = '扎伊爾新扎伊爾';
$string['CHF'] = '瑞士法郎';
$string['CLF'] = '智利比索（可兌換的基金）';
$string['CLP'] = '智利比索';
$string['CNY'] = '人民幣';
$string['COP'] = '哥倫比亞比索';
$string['CRC'] = '哥斯大黎加科郎';
$string['CSD'] = '南斯拉夫第納爾';
$string['CUP'] = '古巴比索';
$string['CVE'] = '維德角埃斯庫多';
$string['CYP'] = '塞普勒斯鎊';
$string['CZK'] = '捷克克朗';
$string['DJF'] = '吉布地法郎';
$string['DKK'] = '丹麥克朗';
$string['DOP'] = '多明尼加比索';
$string['DZD'] = '阿爾及利亞戴納';
$string['EGP'] = '埃及鎊';
$string['ETB'] = '衣索比亞比爾';
$string['EUR'] = '歐元';
$string['FJD'] = '斐濟元';
$string['FKP'] = '福克蘭鎊';
$string['GBP'] = '英鎊';
$string['GHC'] = '迦納塞地';
$string['GIP'] = '直布羅陀鎊';
$string['GMD'] = '甘比亞達拉西';
$string['GNF'] = '幾內亞法郎';
$string['GTQ'] = '格查爾';
$string['GWP'] = '幾內亞比索比索 (被XOF取代)';
$string['GYD'] = '蓋亞那元';
$string['HKD'] = '香港元';
$string['HNL'] = '宏都拉斯倫皮拉';
$string['HTG'] = '海地古德';
$string['HUF'] = '匈牙利富林';
$string['IDR'] = '印度尼西亞盾 / 盧比';
$string['ILS'] = '以色列塞克';
$string['INR'] = '印度盧比';
$string['IQD'] = '伊拉克第納爾';
$string['IRR'] = '伊朗里亞爾';
$string['ISK'] = '冰島克朗';
$string['JMD'] = '牙買加元';
$string['JOD'] = '約旦第納爾';
$string['JPY'] = '日圓';
$string['KES'] = '肯尼亞先令';
$string['KHR'] = '柬埔寨裡耳';
$string['KMF'] = '科摩羅法郎';
$string['KPW'] = '北韓元';
$string['KRW'] = '韓元';
$string['KWD'] = '科威特第納爾';
$string['KYD'] = '開曼元';
$string['LAK'] = '寮國基普';
$string['LBP'] = '黎巴嫩鎊';
$string['LKR'] = '斯里蘭卡盧比';
$string['LRD'] = '賴比瑞亞元';
$string['LSL'] = '賴索托洛蒂';
$string['LYD'] = '利比亞戴納';
$string['MAD'] = '摩洛哥迪拉姆';
$string['MGF'] = '馬達加斯加法郎';
$string['MNT'] = '蒙古圖格里克';
$string['MOP'] = '澳門幣';
$string['MRO'] = '茅利塔尼亞烏吉亞';
$string['MTL'] = '馬爾他里拉';
$string['MUR'] = '模裡西斯盧比';
$string['MVR'] = '馬爾地夫拉菲亞';
$string['MWK'] = '馬拉威誇加';
$string['MXN'] = '墨西哥新比索';
$string['MYR'] = '馬來西亞令吉';
$string['MZM'] = '莫三比克梅蒂卡爾';
$string['NGN'] = '奈及利亞奈拉';
$string['NIO'] = '尼加拉瓜科多巴';
$string['NOK'] = '挪威克郎';
$string['NPR'] = '尼泊爾盧比';
$string['NZD'] = '紐西蘭元';
$string['OMR'] = '阿曼里亞爾';
$string['PAB'] = '巴波亞';
$string['PEN'] = '索爾';
$string['PGK'] = '巴布亞紐幾內亞基那';
$string['PHP'] = '菲國比索';
$string['PKR'] = '巴基斯坦盧比';
$string['PLN'] = '波蘭茲羅提';
$string['PYG'] = '瓜拉尼';
$string['QAR'] = '卡達里亞爾';
$string['ROL'] = '羅馬尼亞羅依';
$string['RWF'] = '盧安達法郎';
$string['SAR'] = '沙烏地里亞爾';
$string['SBD'] = '索羅門群島元';
$string['SCR'] = '塞席爾盧比';
$string['SDP'] = '蘇丹鎊';
$string['SEK'] = '瑞典克郎';
$string['SGD'] = '新加坡元';
$string['SHP'] = '聖赫倫那鎊';
$string['SKK'] = '斯洛伐克克朗';
$string['SLL'] = '獅子山利昂';
$string['SOS'] = '索馬利亞先令';
$string['SRG'] = '蘇利南盾 (被SRD取代)';
$string['STD'] = '聖多美普林西比杜布拉';
$string['SUR'] = '蘇聯盧布';
$string['SVC'] = '薩爾瓦多科郎（也用美元(USD)）';
$string['SYP'] = '敘利亞鎊';
$string['SZL'] = '史瓦濟蘭里蘭吉尼';
$string['THB'] = '泰銖';
$string['TND'] = '突尼西亞第納爾';
$string['TOP'] = '東加潘加';
$string['TPE'] = '帝汶埃斯庫多';
$string['TRL'] = '土耳其裡拉';
$string['TTD'] = '千里達元';
$string['TWD'] = '新台幣元';
$string['TZS'] = '坦尚尼亞先令';
$string['UGS'] = '烏干達先令';
$string['USD'] = '美元';
$string['UYU'] = '烏拉圭比索';
$string['VEB'] = '委內瑞拉玻利瓦';
$string['VND'] = '越南盾';
$string['VUV'] = '萬那杜瓦圖';
$string['WST'] = '薩摩亞塔拉';
$string['YER'] = '葉門里亞爾';
$string['ZAR'] = '南非蘭特';
$string['ZMK'] = '尚比亞克瓦查';
$string['ZWD'] = '辛巴威元';
