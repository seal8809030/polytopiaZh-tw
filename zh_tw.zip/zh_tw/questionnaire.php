<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'questionnaire', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   questionnaire
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action'] = '行動';
$string['additionalinfo'] = '更強資料';
$string['additionalinfo_help'] = '在首頁置頂上顯示的文字（例如：教師，背景資料等）';
$string['addnewquestion'] = '正增加{$a} 問題';
$string['addselqtype'] = '新增指定題型';
$string['alignment'] = '對齊單選按鈕';
$string['alignment_help'] = '對齊選擇按鈕：垂直（預設值）或水平。';
$string['all'] = '全部';
$string['alreadyfilled'] = '您已經填寫了此問卷{$a}。謝謝。';
$string['anonymous'] = '匿名';
$string['average'] = '平均';
$string['averagerank'] = '平均等級';
$string['bodytext'] = '本體';
$string['boxesnbexact'] = '剛好{$a} 格子';
$string['boxesnbmax'] = '{$a} 格子的上限';
$string['boxesnbmin'] = '{$a} 格子的下限';
$string['boxesnbreq'] = '此問題您必須勾選';
$string['by'] = '由';
$string['checkallradiobuttons'] = '請勾選<strong>{$a}</strong>單選按鈕';
$string['checkboxes'] = '勾選格';
$string['checkboxes_help'] = '每行輸入一個選項以令用戶可以選多於一個答案';
$string['closed'] = '問卷在{$a}開閉。謝謝。';
$string['closedate'] = '使用結束日期';
$string['confalts'] = '- 或 - <br />確定頁面';
$string['confirmdelallresp'] = '您確定要刪除所有在問卷的回覆？';
$string['confirmdelgroupresp'] = '您確定要刪除所有在{$a}的回覆？';
$string['confirmdelresp'] = '您確定要刪除&nbsp;{$a}&nbsp;的回覆？';
$string['confpage'] = '隱藏文字';
$string['confpagedesc'] = '當用戶完成此問卷後，題示&quot;確認&quot;頁面中，隱藏（粗體）及本體。（網址（如有），將會先於確認文字）';
$string['confpage_help'] = '當用戶完成此問卷後，題示"確認"頁面中，隱藏（粗體）及本體。（網址（如有），將會先於確認文字）。如果您留空此框，預設訊息將會在完成問卷後顯示（感謝您完成問卷）。';
$string['contentoptions'] = '內容選項';
$string['couldnotcreatenewsurvey'] = '不能建立新問卷！';
$string['couldnotdelresp'] = '不能刪子回覆';
$string['createcontent'] = '界定新內容';
$string['createcontent_help'] = '選擇其中的單項選擇。「建立新的」是預設';
$string['createnew'] = '建立新的';
$string['date'] = '日期';
$string['dateformatting'] = '使用日／月／年的格式，例如March 14th, 1945:&nbsp; <strong>14/3/1945</strong>';
$string['date_help'] = '如果您期望回覆會是正確格式的日期，使用此題型。';
$string['deleteallresponses'] = '刪除所有回覆';
$string['deletecurrentquestion'] = '刪除題目{$a}';
$string['deletedallgroupresp'] = '刪除在群組{$a}的所有回覆';
$string['deletedresp'] = '刪除回覆';
$string['deleteresp'] = '刪除此回覆';
$string['deletingresp'] = '正刪除回覆';
$string['displaymethod'] = '未界定此問題的顯示方式';
$string['download'] = '下載';
$string['downloadtextformat'] = '以文字方式下載';
$string['dropdown'] = '下拉框';
$string['edit'] = '編輯';
$string['editingquestionnaire'] = '編輯問卷設定';
$string['editquestion'] = '編輯 {$a}問題';
$string['email'] = '電郵';
$string['errnewname'] = '抱歉，此名稱已被使用，請選擇其他名稱。';
$string['erroropening'] = '錯誤打開問卷';
$string['errortable'] = '錯誤系統表損壞';
$string['essaybox'] = '評論框';
$string['field'] = '問題{$a}';
$string['fieldlength'] = '輸入框長度';
$string['fieldlength_help'] = '至於**文字框**的題型，輸入回答者回覆的**文字框長度**及** 文字長度上限** 。

在預設數值中，文字框長度為20字元； 文字長度上限為25字元。';
$string['grade'] = '提交分數';
$string['headingtext'] = '標題文字';
$string['horizontal'] = '水平';
$string['id'] = '編號';
$string['includechoicecodes'] = '包括選項編碼';
$string['includechoicetext'] = '包括選項文字';
$string['incorrectcourseid'] = '課程編號不正確';
$string['incorrectmodule'] = '課程模組編號不正確';
$string['incorrectquestionnaire'] = '問卷不正確';
$string['invalidresponse'] = '指明了無效的回覆';
$string['invalidresponserecord'] = '指明了無效回覆的紀錄';
$string['invalidsurveyid'] = '無效問卷編號';
$string['kindofratescale'] = '評分標準的類型';
$string['length'] = '長度';
$string['maxdigitsallowed'] = '最多允許的數字';
$string['maxforcedresponses'] = '強制回答的上限';
$string['maxtextlength'] = '文字長度上限';
$string['minforcedresponses'] = '強制回答的下限';
$string['minforcedresponses_help'] = '使用這些參數來強制回答者點選**最少**格的下限及of **最多** 勾選框的上限.
要強制相同數相的勾選框的數目，設定**最少**及**最多** 至相同數值。如果只需要最少或最多，只需留空一個為預設數值0。如果您設定了**最少**及**最多** 不是預設設定0，當回答者沒有跟從指示時，將會顯示警告訊息。因此，您必須在問卷中的一般說明或相關問題的文字上清晰標明您的指示。';
$string['misconfigured'] = '課程配置錯誤';
$string['modulename'] = '問卷';
$string['modulenameplural'] = '問卷';
$string['myresponses'] = '您的全部回覆';
$string['myresponsetitle'] = '您的{$a} 回覆';
$string['myresults'] = '您的結果';
$string['name'] = '名稱';
$string['next'] = '下一個';
$string['nextpage'] = '下一頁';
$string['noanswer'] = '沒有問題';
$string['nodata'] = '沒有發佈的資料';
$string['noduplicates'] = '沒有重複的選擇';
$string['nopublicsurveys'] = '沒有公開問卷';
$string['noresponsedata'] = '沒有此問題的回覆';
$string['noresponses'] = '沒有回覆';
$string['normal'] = '正常';
$string['notanumber'] = '<strong>{$a}</strong> 不是可接受的數字格式';
$string['notapplicable'] = 'N/A';
$string['notapplicablecolumn'] = 'N/A欄';
$string['noteligible'] = '您不能取得此問卷';
$string['notemplatesurveys'] = '沒有範本問卷。';
$string['notopen'] = '此問卷會直至 {$a}才公開。';
$string['num'] = '＃';
$string['numberfloat'] = '您已輸入的數字<strong>{$a->number}</strong> 已經重新格式化或轉換至<strong>{$a->precision}</strong> 小數位。';
$string['numberofdecimaldigits'] = 'Nb小數位';
$string['numberscaleitems'] = 'Nb項目規模';
$string['numberscaleitems_help'] = 'Nb項目規模是用作您的評標準中的*項目數目*。您一般會使用3至5的數值。預設值為**5**';
$string['numeric'] = '數字';
$string['numeric_help'] = '使用此題型如果您期望回覆會是正確格式的數字';
$string['of'] = '的';
$string['opendate'] = '使用公開日期';
$string['option'] = '選項 {$a}';
$string['optionalname'] = '問題名稱';
$string['or'] = '－或－';
$string['order_ascending'] = '由小至大的順序（升序）';
$string['order_default'] = '查看預設順序';
$string['order_descending'] = '由大至小的順序（降序）';
$string['orderresponses'] = '排序回覆';
$string['osgood'] = 'Osgood';
$string['other'] = '其他：';
$string['otherempty'] = '如果您勾選此選項，您必須在文字框輸入文字！';
$string['overviewnumresplog'] = '回覆';
$string['overviewnumresplog1'] = '回覆';
$string['overviewnumrespvw'] = '回覆';
$string['overviewnumrespvw1'] = '回覆';
$string['owner'] = '擁有者';
$string['page'] = '頁';
$string['pageof'] = '{$a->totpages}頁中的{$a->page}頁';
$string['pluginadministration'] = '問卷管理';
$string['pluginname'] = '問卷';
$string['possibleanswers'] = '可能答案';
$string['posteddata'] = '與發佈資料前往頁面：';
$string['previewing'] = '預覽問卷';
$string['preview_label'] = '預覽';
$string['previous'] = '前';
$string['previouspage'] = '上一頁';
$string['print'] = '列印此回覆';
$string['printblank'] = '列印空白';
$string['printblanktooltip'] = '與空白問卷開啟打印機友善視窗';
$string['printtooltip'] = '與現有回覆開啟打印機友善視窗';
$string['private'] = '私人';
$string['public'] = '公開';
$string['qtype'] = '類型';
$string['qtypedaily'] = '每日回覆';
$string['qtype_help'] = '選擇允許用戶一次、每日、每週、每月或無限回覆。';
$string['qtypemonthly'] = '每月回覆';
$string['qtypeonce'] = '回覆一次';
$string['qtypeunlimited'] = '回覆多次';
$string['qtypeweekly'] = '每週回覆';
$string['questionnaireadministration'] = '問卷管理';
$string['questionnairecloses'] = '問卷關閉';
$string['questionnaire:copysurveys'] = '複製範本及私人問卷';
$string['questionnaire:createpublic'] = '建立公開問卷';
$string['questionnaire:createtemplates'] = '建立範本問卷';
$string['questionnaire:deleteresponses'] = '刪除任何回覆';
$string['questionnaire:downloadresponses'] = '以CSV檔案下載回覆';
$string['questionnaire:editquestions'] = '建立及編輯問卷問題';
$string['questionnaire:manage'] = '建立及編輯問卷';
$string['questionnaireopens'] = '問卷開啟';
$string['questionnaire:printblank'] = '列印空白問卷';
$string['questionnaire:readallresponseanytime'] = '任何時候閱覽全部回覆';
$string['questionnaire:readallresponses'] = '閱覽回覆摘要，根據打開次數';
$string['questionnaire:readownresponses'] = '閱覽自己的回覆';
$string['questionnairereport'] = '問卷報告';
$string['questionnaire:submit'] = '完成及提交問卷';
$string['questionnaire:view'] = '查看問卷';
$string['questionnaire:viewsingleresponse'] = '查看完整的個人回覆';
$string['questionnum'] = '問題＃';
$string['questions'] = '問題';
$string['questiontypes'] = '問題類型';
$string['questiontypes_help'] = '在下方查看Moodle文檔';
$string['radiobuttons'] = '單選按鈕';
$string['radiobuttons_help'] = '在此題型，回答者必須提供的選項中選擇。';
$string['rank'] = '等級';
$string['ratescale'] = '評分（級別1..5）';
$string['ratescale_help'] = '在下方查看Moodle文檔';
$string['realm'] = '問卷類型';
$string['realm_help'] = '**有三類型的問卷：**
＊私人：只屬於已界定的課程
＊範本：可以複製及修改
＊公開：可以與課程之間共享';
$string['redirecturl'] = '在完成問卷後將重新定向用戶的網址';
$string['remove'] = '刪除';
$string['required_help'] = '如果您選擇***是***，此問題的回覆是必需的，例如，直至已回答所有問題前，回答者將不能提交問卷。';
$string['requiredparameter'] = '缺少了必要的參數';
$string['reset'] = '重設';
$string['respeligiblerepl'] = '（按角色覆蓋取代）';
$string['respondent'] = '回答者';
$string['respondenteligibleall'] = '全部';
$string['respondenteligiblestudents'] = '只有學生';
$string['respondenteligibleteachers'] = '只有教師';
$string['respondents'] = '回答者';
$string['respondenttype'] = '回答者類型';
$string['respondenttypeanonymous'] = '匿名';
$string['respondenttypefullname'] = '完整姓名';
$string['respondenttype_help'] = '設定成「完整姓名」，您可以在每個回覆中顯示用戶的完整姓名。
設定成「匿名」，您可以在每個回覆中隱藏用戶的身份。';
$string['response'] = '回覆';
$string['responseoptions'] = '回覆選項';
$string['responses'] = '回覆';
$string['responseview'] = '學生可以查看所有回覆';
$string['responseview_help'] = '您可以指明誰可以查看已提交問卷的回覆（一般統計表格）';
$string['responseviewstudentsalways'] = '總是';
$string['responseviewstudentsnever'] = '永不';
$string['responseviewstudentswhenanswered'] = '在回答問卷之後';
$string['responseviewstudentswhenclosed'] = '在問卷關閉之後';
$string['restrictedtoteacher'] = '這些功能只限於編輯教師';
$string['resume'] = '儲存／恢復答案';
$string['resumesurvey'] = '恢復問卷';
$string['return'] = '返回';
$string['save'] = '儲存';
$string['saveasnew'] = '儲存成新題目';
$string['saveeditedquestion'] = '儲存問題{$a}';
$string['savesettings'] = '儲存設定';
$string['section'] = '描述';
$string['sectionbreak'] = '----- 分頁符 -----';
$string['sectionbreak_help'] = '----- 分頁符 -----';
$string['sectiontext'] = '標籤';
$string['sectiontext_help'] = '這不是一個問題但是一個用題示作簡介以下題目的短文';
$string['selecttheme'] = '選擇此問卷的主題（css）';
$string['sendemail'] = '傳送電郵';
$string['sendemail_help'] = '傳送副本到指定的電郵地址。您可以提供多於一個電郵地址，並以逗號作分隔。留空如果沒有電郵備份。';
$string['settings'] = '設定';
$string['settingssaved'] = '已儲存設定';
$string['strfdate'] = '%d/%m/%Y';
$string['strfdateformatcsv'] = 'd/m/Y H:i:s';
$string['submitoptions'] = '遞交選項';
$string['submitsurvey'] = '繳交問卷';
$string['submitted'] = '提交在：';
$string['subtitle'] = '子標題';
$string['subtitle_help'] = '此問卷的子標題。';
$string['summary'] = '摘要';
$string['surveynotexists'] = '問卷不存在';
$string['surveyowner'] = '您必須是問卷的擁有者以進行此操作';
$string['surveyresponse'] = '問卷中的回覆';
$string['template'] = '範本';
$string['templatenotviewable'] = '問卷範本不能查看。';
$string['text'] = '問題文字';
$string['textareacolumns'] = '文本區域欄';
$string['textareacolumns_help'] = '此問題會以純文字框顯示，與**x** *文本區域欄* (或面積 *閣度*) 及 **y** *文本區域行* (文字數目
*行*).';
$string['textarearows'] = '文本區域行';
$string['textbox'] = '文字框';
$string['textbox_help'] = '至於文字框題型，輸入回答者的文字框長度及文字長度上限。
輸入框闊度的預設設定是20字元，文字長度上限的預設設定是25字元。';
$string['textdownloadoptions'] = '文字下載的選項（CSV）';
$string['thank_head'] = '感謝您完成問卷。';
$string['theme'] = '主題';
$string['thismonth'] = '此月份';
$string['thisweek'] = '此週';
$string['title'] = '標題';
$string['title_help'] = '為問卷命名標題，將會在每頁的置頂中顯示。在預設設定中，標題設定為問卷名稱，但您可以修改成您想要的。';
$string['today'] = '今天';
$string['total'] = '總共';
$string['type'] = '題目煩型';
$string['undefinedquestiontype'] = '未定義題型';
$string['unknown'] = '不知明';
$string['unknownaction'] = '指定了不知明問卷行動';
$string['url'] = 'URL確認';
$string['url_help'] = '此URL將會在用戶完成問卷後重新定向';
$string['usepublic'] = '使用公開';
$string['vertical'] = '垂直';
$string['view'] = '查看';
$string['viewallresponses'] = '查看全部回覆';
$string['viewresponses'] = '全部回覆 ({$a})';
$string['viewyourresponses'] = '您的回覆－ 查看{$a}';
$string['warning'] = '警告：遇到錯誤';
$string['wrongdateformat'] = '輸入的日期：<strong>{$a}</strong>不符合例子中的格式。';
$string['wrongdaterange'] = '錯誤！年份必須設定在1902至2037期間。';
$string['yesno'] = '是／否';
$string['yesno_help'] = '簡單是非題';
