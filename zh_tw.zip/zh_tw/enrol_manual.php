<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_manual', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   enrol_manual
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignrole'] = '分配角色';
$string['defaultperiod'] = '預設選課時間';
$string['defaultperiod_desc'] = '選課有效的預設時間長度（以秒為單位）。如果此時間設定為0，選課開放時間將會預設為不限制。';
$string['defaultperiod_help'] = '預設的使用者身份有效時間長度，從使用者自行加入的課程算起。禁止此選項意味著預設使用者身份永遠有效。';
$string['enrolledincourserole'] = '在 "{$a->course}" 課程註冊為 "{$a->role}" 角色';
$string['enrolusers'] = '加入使用者到此課程';
$string['manual:config'] = '設定手動選課實體';
$string['manual:enrol'] = '加入使用者到此課程';
$string['manual:manage'] = '管理使用者選課';
$string['manual:unenrol'] = '把使用者退出選課';
$string['manual:unenrolself'] = '把自己退選';
$string['pluginname'] = '手動選課';
$string['pluginname_desc'] = '透過手動選課外掛程式，有權限的使用者（例如老師）可以在課程管理設定中的一個連結中手動為其他使用者選課。此外掛程式通常是啟用的，因為有其他外掛程式（例如自行選課）需要使用它。';
$string['status'] = '啟用手動選課';
$string['status_desc'] = '允許內部選課的使用者瀏覽課程。大部分情況都應該啟用這個選項。';
$string['statusdisabled'] = '停用';
$string['statusenabled'] = '啟用';
$string['status_help'] = '此設定決定使用者是否可以被手動選課。老師等有權限的使用者可以在課程管理設定中的一個連結裡面手動選擇使用者，加入課程。';
$string['unenrolselfconfirm'] = '您確定要退選自己對“{$a}”課程的選課嗎？';
$string['unenroluser'] = '您確定要退選使用者“{$a->user}”對“{$a->course}”課程的選課嗎？';
$string['unenrolusers'] = '退選使用者';
$string['wscannotenrol'] = '外掛程式實體無法手動把一個使用者加入id = {$a->courseid}}的課程';
$string['wsnoinstance'] = '對於課程（id = {$a->courseid}），手動選課外掛程式實體不存在或者被停用';
$string['wsusercannotassign'] = '您在課程({$a->courseid})中沒有權限為向使用者({$a->userid})指定這一個角色({$a->roleid})。';
