<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_search', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   block_search
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['blockssearchswitches'] = 'Bytes (0 代表沒有限制)';
$string['bytes'] = 'Bytes (0 代表沒有限制)';
$string['cmdtoconverttotextfor'] = '命令{$a}轉換成文字';
$string['configenablefileindexing'] = '啟用檔案索引';
$string['configfiletypes'] = '處理的檔案類型';
$string['configlimitindexbody'] = '索引大小限制';
$string['configpdftotextcmd'] = 'pdf 轉換成 txt 的工具路徑';
$string['configtypetotxtcmd'] = '轉換程序命令列';
$string['configtypetotxtenv'] = '轉換程序環境變數';
$string['configwordtotextcmd'] = 'doc 轉換成 txt 的工具路徑';
$string['configwordtotextenv'] = '微軟WORD轉換工具的環境設定';
$string['enablefileindexing'] = '開啟對於不同檔案類型的索引';
$string['enableindexinginblock'] = '啟用對{$a}區塊的索引';
$string['enableindexinginmodule'] = '啟用對{$a}區塊的索引';
$string['envforcmdtotextfor'] = '{$a}文字轉換命令的環境';
$string['go'] = '搜尋！';
$string['handlingfor'] = '更多的控制項目';
$string['indexbodylimit'] = '索引主體的限制';
$string['listoffiletypes'] = '可以處理文件類型列表';
$string['modulessearchswitches'] = '啟用了索引的模組';
$string['nosearchableblocks'] = '沒有可搜尋的模組';
$string['nosearchablemodules'] = '沒有可搜尋的模組';
$string['pdfhandling'] = '處理Acrobat PDF';
$string['pdftotextcmd'] = '命令將PDF轉換為為字';
$string['pluginname'] = '全站搜尋';
$string['searchdiscovery'] = '可搜尋的項目';
$string['searchmoodle'] = '搜尋Moodle';
$string['usemoodleroot'] = '外部轉換器使用moodle跟目錄';
$string['usemoodlerootdescription'] = '外部轉換器使用moodle跟目錄';
$string['wordhandling'] = '處理Microsoft Word';
$string['wordtotextcmd'] = '命令將Microsoft Word轉換成純文字';
$string['wordtotextenv'] = '用於Microsoft Word文字轉換器的環境';
