<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_self', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   enrol_self
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['customwelcomemessage'] = '自訂歡迎訊息';
$string['defaultrole'] = '預設分配的角色';
$string['defaultrole_desc'] = '選擇使用者自行選課後被分配的角色';
$string['enrolenddate'] = '結束日期';
$string['enrolenddate_help'] = '如果啟用，使用者只能在此日期前自行加入此課程。';
$string['enrolenddaterror'] = '選課的結束日期不可以早於開始日期。';
$string['enrolme'] = '將我加入';
$string['enrolperiod'] = '報名時間';
$string['enrolperiod_desc'] = '預設的報名時間有效的時間長度(以秒為單位）。如果設定為0，就預設不限制報名時間長度。';
$string['enrolperiod_help'] = '使用者身份有效時間長度，從使用者自行加入課程日期算起。停用此項目表示著使用者身份永遠有效。';
$string['enrolstartdate'] = '開始日期';
$string['enrolstartdate_help'] = '如果啟用，使用者只能在此日期之後自行加入此課程。';
$string['groupkey'] = '使用群組選課密碼';
$string['groupkey_desc'] = '預設使用群組選課密碼。';
$string['groupkey_help'] = '除了只限制知道密碼的使用者瀏覽課程以外，還可以讓使用者在選課時輸入分組密碼，這樣他就能自動加入到小組中。

要使用分組選課密碼，必須在群組設定中設定群組密碼的同時，在課程中設定選課密碼。';
$string['longtimenosee'] = '多就不活動就取消選課';
$string['longtimenosee_help'] = '如果使用者很長時間沒有瀏覽課程，那麼可以自動取消他們的選課。此參數決定這個期限。';
$string['maxenrolled'] = '最大的選課使用者數目';
$string['maxenrolled_help'] = '指定可以自行選課的最大使用者數目。0表示無限制。';
$string['maxenrolledreached'] = '已經達到自行選課使用者數目的上限。';
$string['password'] = '選課密碼';
$string['password_help'] = '只有知道選課密碼的人才能瀏覽課程。

如果此處空白，那麼任何人都可以隨意選課。

如果指定選課密碼後，任何想選課的使用者都必須輸入這個密碼，他們只需要輸入一次就能完成選課。';
$string['passwordinvalid'] = '選課密碼錯誤，請重試';
$string['passwordinvalidhint'] = '所輸入的選課密碼不正確, 請重新輸入<br />(提示 - 以{$a}為開頭)';
$string['pluginname'] = '自行選課';
$string['pluginname_desc'] = '透過自行選課外掛程式，使用者可以自己選擇想參加的課程。可以透過選課密碼保護課程。選課過程是透過人工選課外掛程式完成的，所以必須在課程中啟用這個外掛程式。';
$string['requirepassword'] = '必須設定選課密碼';
$string['requirepassword_desc'] = '新的課程必須設定選課密碼，舊課程不能刪除已經有的選課密碼。';
$string['role'] = '預設分配的角色';
$string['self:config'] = '設定自行選課實體';
$string['self:manage'] = '管理已經選課使用者';
$string['self:unenrol'] = '退選已經選課使用者';
$string['self:unenrolself'] = '退選自己的選課';
$string['sendcoursewelcomemessage'] = '傳送課程的歡迎訊息';
$string['sendcoursewelcomemessage_help'] = '如果啟用，使用者自行選課時會收到一封歡迎信件。';
$string['showhint'] = '顯示提示';
$string['showhint_desc'] = '顯示訪客密碼的第一個字母';
$string['status'] = '允許自行選課';
$string['status_desc'] = '預設允許使用者自行選課。';
$string['status_help'] = '此設定決定使用者是否能自行選課（如果他們有對應的權限，也可以自己退選）。';
$string['unenrolselfconfirm'] = '您確定要取消您自己對"{$a}"課程的選課嗎？';
$string['usepasswordpolicy'] = '使用密碼規則';
$string['usepasswordpolicy_desc'] = '對選課密碼使用標準的密碼規則。';
$string['welcometocourse'] = '歡迎到 {$a}';
$string['welcometocoursetext'] = '歡迎進入 {$a->coursename}!

您所需處理的第一件事是先修改個人設定 以便他人可以多了解您:

  {$a->profileurl}';
