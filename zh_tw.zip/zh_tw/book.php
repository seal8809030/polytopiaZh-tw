<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'book', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   book
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addafter'] = '添加新章節';
$string['book:edit'] = '修改圖書章節';
$string['book:exportimscp'] = '導出圖書爲IMS內容包';
$string['book:import'] = '導入章節';
$string['book:print'] = '打印圖書';
$string['book:read'] = '閱讀圖書';
$string['book:viewhiddenchapters'] = '查看隱藏的圖書章節';
$string['chapterscount'] = '章節';
$string['chaptertitle'] = '章節名';
$string['confchapterdelete'] = '確定要刪除此章節麼？';
$string['confchapterdeleteall'] = '確定要刪除此章節以及其所有子章節麼？';
$string['content'] = '內容';
$string['customtitles'] = '自訂標題';
$string['customtitles_help'] = '只在目錄中自動顯示章節標題。';
$string['doexport'] = '導出';
$string['doimport'] = '導入';
$string['editingchapter'] = '編輯章節';
$string['errorchapter'] = '讀取章節發生錯誤';
$string['faq'] = '書籍FAQ';
$string['faq_help'] = '*爲什麼僅有兩級？*

因爲通常對於絕大多數的書，兩級已經足夠了 ，三級就會導致結構不良。圖書模塊是爲了製作簡短的多頁學習材料而設計的。通常對於更長的文檔用PDF格式較好。最簡單的製作PDF的方法是用虛擬打印機（參考
<a  href="http://sector7g.wurzel6.de/pdfcreator/index_en.htm"  target="_blank">PDFCreator</a>、<a  href="http://fineprint.com/products/pdffactory/index.html"  target="_blank">PDFFactory</a>、<a  href="http://www.adobe.com/products/acrobatstd/main.html"  target="_blank">Adobe Acrobat</a>,
等）。

*學生能編輯圖書嗎？*

只有老師才能製作和編輯圖書。目前我們還沒有使學生能夠編輯的計劃，但是有人爲學生做了些類似的東西。這樣做主要是爲了讓圖書模塊儘可能保持簡潔。

*我該怎樣搜索圖書呢？*

目前只有一個辦法，那就是在打印頁面中使用瀏覽器的搜索功能。現在只在Moodle討論區裏可以全文搜索。如果能夠全面的搜索所有資源，包括圖書，那將會很棒。有志願者願意做嗎？

*我的標題一行容納不下。*

修改標題或者讓網站管理員修改目錄的寬度。它是一個影響所有圖書的全局配置，在模塊配置頁面修改。';
$string['fileordir'] = '文件或目錄';
$string['generateimscp'] = '生成IMS內容包';
$string['import'] = '導入';
$string['import_help'] = '您可以導入一個單獨的HTML文件或者一個目錄中的所有HTML文件。相關的文件鏈接會被轉換成絕對章節鏈接。圖像、flash 和 java 也會被重新連接。';
$string['importinfo'] = '導入選中的HTML文件或目錄。<br/>章節是按照文件名字典序排列的。<br/>命名爲\'sub_*.*\'的文件永遠被作爲子章節導入。';
$string['importing'] = '正在導入';
$string['importingchapters'] = '將章節導入到圖書中';
$string['maindirectory'] = '主目錄';
$string['modulename'] = '圖書';
$string['modulename_help'] = '圖書是一種簡單的多頁學習資料。';
$string['modulenameplural'] = '圖書';
$string['navexit'] = '退出圖書';
$string['navnext'] = '下一個';
$string['navprev'] = '前一個';
$string['numbering'] = '章節編號';
$string['numbering0'] = '無';
$string['numbering1'] = '數字';
$string['numbering2'] = '項目列表';
$string['numbering3'] = '縮排';
$string['numbering_help'] = '* 無 - 章及節的標題都完全不做格式化。如果您想自定義特殊編號方式，就選這個。例如：在章節標題輸入“A 第一章”，“A.1 某小節”，……
* 編號 - 章及節都是編號的（1，1.1，1.2，2，……）
* 項目符號 - 節是縮進的並且帶有項目符號
* 縮進 - 節是縮進的';
$string['numberingoptions'] = '可用的編號選項';
$string['numberingoptions_help'] = '選擇在創建圖書時可用的編號選項。';
$string['pluginadministration'] = '圖書管理';
$string['pluginname'] = '圖書';
$string['printbook'] = '打印圖書';
$string['printchapter'] = '打印本章節';
$string['printdate'] = '日期';
$string['relinking'] = '重新鏈接';
$string['subchapter'] = '子章節';
$string['toc'] = '目錄';
$string['top'] = '頂端';
