<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'booking', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   booking
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addeditbooking'] = '編輯劃位';
$string['addmorebookings'] = '新增更多座位/席次';
$string['addnewbookingoption'] = '增加新劃位選項';
$string['agreetobookingpolicy'] = '我已閱讀並同意劃位規則';
$string['allbookingoptions'] = '下載所有劃位選項的使用者';
$string['allowdelete'] = '允許自行取消劃位';
$string['allowupdate'] = '允許劃位被更新';
$string['answered'] = '已回覆';
$string['associatedcourse'] = '被關連的課程';
$string['availability'] = '仍可劃位';
$string['available'] = '仍有空位';
$string['booked'] = '已劃位';
$string['bookedusers'] = '已劃位使用者';
$string['booking'] = '劃位';
$string['bookingclose'] = '直到';
$string['bookingdeleted'] = '你的劃位已被取消';
$string['booking:deleteresponses'] = '刪除回應';
$string['booking:downloadresponses'] = '下載回應';
$string['bookingfull'] = '已無空位';
$string['bookingmeanwhilefull'] = '最位空位已被佔。';
$string['bookingname'] = '劃位名稱';
$string['bookingopen'] = '開放';
$string['bookingpolicy'] = '劃位規則';
$string['booking:readresponses'] = '讀取回應';
$string['bookingsaved'] = '你的劃位已儲存.現在可以繼續其他課程的劃位';
$string['bookingtext'] = '劃位說明';
$string['booking:updatebooking'] = '管理劃位選項';
$string['booknow'] = '馬上登記';
$string['cancelbooking'] = '取消劃位';
$string['choosecourse'] = '選擇課程';
$string['closed'] = '劃位已關閉';
$string['confirmationmessagesettings'] = '確認郵件設定';
$string['confirmbookingoffollowing'] = '請確認下列課程的劃位';
$string['confirmdeletebookingoption'] = '是否刪除劃位選項';
$string['coursedate'] = '日期';
$string['courseendtime'] = '課程結束時間';
$string['coursestarttime'] = '課程開始時間';
$string['createdby'] = 'Booking module created by edulabs.org';
$string['defaultbookingoption'] = '預設劃位選項';
$string['deletebooking'] = '您是否真要解除訂閱下列課程? <br /><br /> <b>{$a} </b>';
$string['deletebookingoption'] = '刪除劃位選項';
$string['deleteuserfrombooking'] = '是否要刪除劃位的使用者';
$string['donotselectcourse'] = '無選擇課程';
$string['download'] = '下載';
$string['downloadallresponses'] = '下載所有劃位選項的所有回應';
$string['downloadusersforthisoptionods'] = '下載使用者為 .ods';
$string['downloadusersforthisoptionxls'] = '下載使用者為 .xls';
$string['endtimenotset'] = '結束日期未設置';
$string['expired'] = '抱歉,活動結束於 {$a} 無法使用';
$string['fillinatleastoneoption'] = '需至少提供二個可能的答案';
$string['full'] = '完整';
$string['havetologin'] = '傳送劃位資訊前須登入本網站';
$string['limit'] = '限制';
$string['limitanswers'] = '參與人員的限制人數';
$string['mailconfirmationsent'] = '將儘速收到確認郵件';
$string['managebooking'] = '管理';
$string['maxoverbooking'] = '最大數,置於候選列表的數量';
$string['maxparticipantsnumber'] = '最大數,參與人員的數量';
$string['modulename'] = '劃位';
$string['modulenameplural'] = '劃位';
$string['mustfilloutuserinfobeforebooking'] = '處理劃位表單前，請完成個人劃位資訊';
$string['nobookingselected'] = '無劃位選項被選取';
$string['noguestchoose'] = '抱歉,訪客不允許輸入資料';
$string['noresultsviewable'] = '結果目前無法被檢視';
$string['norighttobook'] = '您的使用者角色無法劃位，請登入您的帳號或連絡管理員授予權限或';
$string['notbooked'] = '還未被劃位';
$string['notopenyet'] = '抱歉,此活動未可用直到 {$a}';
$string['onwaitinglist'] = '於候選列表中';
$string['pluginadministration'] = '劃位管理';
$string['pluginname'] = '劃位';
$string['removeresponses'] = '移除所有回應';
$string['responses'] = '回應';
$string['responsesto'] = '回應到 {$a}';
$string['select'] = '選擇';
$string['sendconfirmmail'] = '寄送確認信';
$string['sendconfirmmailtobookingmanger'] = '寄送確認件給劃位管理者';
$string['spaceleft'] = '席次開放';
$string['spacesleft'] = '席次開放';
$string['startendtimeknown'] = '課程開始及結束時間已知悉';
$string['starttimenotset'] = '開始日期未設置';
$string['submitandaddnew'] = '儲存後新增';
$string['subscribetocourse'] = '使用者報名課程(Enrol users in the course)';
$string['subscribeuser'] = '在下列課程中進行選課';
$string['taken'] = '拿取';
$string['unlimited'] = '無限制';
$string['updatebooking'] = '編輯劃位選項';
$string['userdownload'] = '下載使用者';
$string['usernameofbookingmanager'] = '劃位管理者的Username';
$string['viewallresponses'] = '管理 {$a} 回應';
$string['waitinglisttaken'] = '在候選列表中';
$string['waitinglistusers'] = '使用者在候選列表中';
$string['waitspaceavailable'] = '候選列表可用';
$string['withselected'] = '被選使用者：';
$string['yourselection'] = '你的選取';
