<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'quiz_grading', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   quiz_grading
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cannotloadquestioninfo'] = '無法上載題型指定的試題資訊';
$string['essayonly'] = '下列試題需要人工閱卷';
$string['graded'] = '(已評分)';
$string['gradenextungraded'] = '評閱下{$a}個還未評分的作答';
$string['gradeungraded'] = '評閱全部{$a}個還未評分的作答';
$string['grading'] = '人工閱卷';
$string['gradingall'] = '這一試題的全部 {$a}作答';
$string['gradingattempt'] = '作答編號 {$a->attempt} 在試題 {$a->fullname}';
$string['gradingnextungraded'] = '下 {$a}個還沒評分的作答';
$string['gradingnotallowed'] = '您沒有人工閱卷的權限';
$string['gradingreport'] = '人工閱卷報告';
$string['gradingungraded'] = '有{$a}個未被評閱的作答';
$string['gradinguser'] = '{$a}的作答次';
$string['invalidattemptid'] = '沒有這個作答編號';
$string['invalidquestionid'] = '找不到編號 {$a} 的可計分試題';
$string['questiontitle'] = '題號 {$a->number} : "{$a->name}" ({$a->openspan}{$a->gradedattempts}{$a->closespan} / {$a->totalattempts} 作答 {$a->openspan}評分{$a->closespan})。';
