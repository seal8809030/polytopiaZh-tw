<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'portfolio', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   portfolio
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activeexport'] = '解析活動的匯出';
$string['activeportfolios'] = '可選的文件包';
$string['addalltoportfolio'] = '全部導出到文件包';
$string['addnewportfolio'] = '添加一個新文件包';
$string['addtoportfolio'] = '導出到文件包';
$string['alreadyalt'] = '已經在匯出-請點選此處解析這次傳送';
$string['alreadyexporting'] = '您這次工作階段已經有一個活動的學習歷程匯出。在繼續之前，您必須完成此匯出，或者放棄它。您要繼續完成匯出嗎？（"否"會放棄它）';
$string['availableformats'] = '可選的導出格式';
$string['callbackclassinvalid'] = '給定的回調類無效，或它不是繼承自portfolio_caller';
$string['callercouldnotpackage'] = '導出前進行數據打包時發生錯誤：原始錯誤是{$a}';
$string['cannotsetvisible'] = '無法設爲可見 - 因爲配置錯誤，此插件被完全禁用';
$string['commonportfoliosettings'] = '常用文件包設置';
$string['commonsettingsdesc'] = '<p>一次傳輸要花費的時間被視作“中度”還是“大量”決定了用戶是否可以等待傳輸結束。</p><p>小於“適度”閾值的文件會被立刻傳輸，不會詢問用戶。而“中度”和“大量”的傳輸會先給用戶選項，並警告他們這可能會消耗一些時間。</p><p>另外，某些文件包插件會完全忽略此選項，強制所有傳輸必須排隊。</p>';
$string['configexport'] = '配置導出的數據';
$string['configplugin'] = '配置文件包插件';
$string['configure'] = '配置';
$string['confirmcancel'] = '您確定要放棄本次導出？';
$string['confirmexport'] = '請確認本次導出';
$string['confirmsummary'] = '導出總結';
$string['continuetoportfolio'] = '繼續導出到您的文件包';
$string['deleteportfolio'] = '刪除文件包實例';
$string['destination'] = '目的地';
$string['disabled'] = '抱歉，但是本站沒有啓用文件包導出功能';
$string['disabledinstance'] = '已禁用';
$string['displayarea'] = '導出區域';
$string['displayexpiry'] = '傳輸到期時間';
$string['displayinfo'] = '導出信息';
$string['dontwait'] = '不要等待';
$string['enabled'] = '啓用文件包';
$string['enableddesc'] = '啓用後，管理員可以配置供用戶導出內容的遠程系統';
$string['err_uniquename'] = '每個插件的文件包名必須唯一';
$string['exportalreadyfinished'] = '文件包導出成功！';
$string['exportalreadyfinisheddesc'] = '學習歷程匯出完成！';
$string['exportcomplete'] = '文件包導出成功！';
$string['exportedpreviously'] = '以前的導出';
$string['exportexceptionnoexporter'] = '一個工作階段 portfolio_export_exception 被拋出，也沒有匯出目標。';
$string['exportexpired'] = '已過期的文件包導出';
$string['exportexpireddesc'] = '您曾反覆嘗試導出某些信息，或者啓動一個空的導出。正確的操作是，回退到原始位置並重新開始。發生此種情況一般是因爲在導出結束後，您按了返回按鈕，或者收藏了一個不正確的url。';
$string['exporting'] = '正在向文件包導出';
$string['exportingcontentfrom'] = '正在從{$a}導出內容';
$string['exportingcontentto'] = '正在向{$a}導出內容';
$string['exportqueued'] = '已成功將文件包導出放入傳輸隊列';
$string['exportqueuedforced'] = '已成功將文件包導出放入傳輸隊列（遠程系統要求必須將傳輸排隊）';
$string['failedtopackage'] = '無法找到檔案來打包';
$string['failedtosendpackage'] = '將您的數據發往您選擇的文件包系統時出錯：原始錯誤信息是{$a}';
$string['filedenied'] = '文件訪問被拒絕';
$string['filenotfound'] = '找不到文件';
$string['fileoutputnotsupported'] = '此格式不支持重寫文件輸出';
$string['format_document'] = '文檔';
$string['format_file'] = '文件';
$string['format_image'] = '圖片';
$string['format_leap2a'] = 'Leap2A文件包格式';
$string['format_mbkp'] = 'Moodle備份格式';
$string['format_pdf'] = 'PDF';
$string['format_plainhtml'] = 'HTML';
$string['format_presentation'] = '幻燈片';
$string['format_richhtml'] = '帶附件的HTML';
$string['format_spreadsheet'] = '電子表格';
$string['format_text'] = '純文本';
$string['format_video'] = '視頻';
$string['hidden'] = '隱藏';
$string['highdbsizethreshold'] = '大量傳送資料大小';
$string['highdbsizethresholddesc'] = '資料庫資料筆數超過多少將會被認為會使用大量傳送時間。';
$string['highfilesizethreshold'] = '大量傳輸文件大小';
$string['highfilesizethresholddesc'] = '大小超過此閾值的文件會被視爲將消耗大量傳輸時間';
$string['insanebody'] = '您好！因爲您是{$a->sitename}的管理員，所以您會收到此信息。

因爲配置錯誤，一些文件包插件被自動禁用。這意味着用戶現在不能向這些文件包導出數據。

被禁用的文件包插件有：

{$a->textlist}

請即刻訪問 {$a->fixurl} ，馬上修正此問題。';
$string['insanebodyhtml'] = '<p>您好！因爲您是{$a->sitename}的管理員，所以您會收到此信息。</p>
<p>因爲配置錯誤，一些文件包插件被自動禁用。這意味着用戶現在不能向這些文件包導出數據。</p>
<p>被禁用的文件包插件有：</p>
{$a->htmllist}
<p>請即刻訪問<a href="{$a->fixurl}">文件包配置頁</a> ，馬上修正此問題。</p>';
$string['insanebodysmall'] = '您好！因爲您是{$a->sitename}的管理員，所以您會收到此信息。因爲配置錯誤，一些文件包插件被自動禁用。這意味着用戶現在不能向這些文件包導出數據。請即刻訪問 {$a->fixurl} ，馬上修正此問題。';
$string['insanesubject'] = '某些文件包實例已被自動禁用';
$string['instancedeleted'] = '成功刪除文件包';
$string['instanceismisconfigured'] = '文件包實例配置不正確，跳過。錯誤是：{$a}';
$string['instancenotdelete'] = '無法刪除學習歷程';
$string['instancenotsaved'] = '保存文件包出錯';
$string['instancesaved'] = '成功保存文件包';
$string['invalidaddformat'] = '傳送給portfolio_add_button的附加格式無效。({$a})必須是PORTFOLIO_ADD_XXX 中的一個';
$string['invalidbuttonproperty'] = '找不到portfolio_button 的屬性（{$a}）';
$string['invalidconfigproperty'] = '找不到設定屬性（{$a->class} 的 {$a->property}）';
$string['invalidexportproperty'] = '找不到匯出設定屬性（{$a->class} 的 {$a->property}）';
$string['invalidfileareaargs'] = '傳送給set_file_and_format_data 的檔案區域參數無效-必須包含contextid、component、fileare 和 itemid';
$string['invalidformat'] = '正在匯出無效格式，{$a}';
$string['invalidinstance'] = '找不到該文件包實例';
$string['invalidpreparepackagefile'] = '呼叫prepare_package_file無效-必須設定single 或 multifiles';
$string['invalidproperty'] = '找不屬性（{$a->class} 的 {$a->property}）';
$string['invalidsha1file'] = '呼叫get_sha1_file 無效 — 必須設定 single 或 multifiles';
$string['invalidtempid'] = '無效的匯出id。可能它已經逾期';
$string['invaliduserproperty'] = '找不到使用者設定屬性（{$a->class} 的 {$a->property}）';
$string['leap2a_emptyselection'] = '沒有選出必要的值';
$string['leap2a_entryalreadyexists'] = '您試著加入的id為{$a}的Leap2A項目在feed中已經存在。';
$string['leap2a_feedtitle'] = '為{$a}從Moodle匯出Leap2A';
$string['leap2a_filecontent'] = '試圖設定Leap2A項的內容到檔案，而不是使用檔案子類別。';
$string['leap2a_invalidentryfield'] = '您試圖設定一個不存在的欄位項目（{$a}），或者您不能直接設定';
$string['leap2a_invalidentryid'] = '您試著用一個不存在的id連接一個項目({$a})';
$string['leap2a_missingfield'] = '缺少必要的Leap2A項目欄位{$a}';
$string['leap2a_nonexistantlink'] = '一個Leap2A項目($a->from})試著用rel{$a->rel}連結到一個不存在的項目{$a->to})';
$string['leap2a_overwritingselection'] = '在make_selection中覆蓋項目({$a})的原始類型來選擇類型';
$string['leap2a_selflink'] = '一個Leap2A項($a->id})試圖用rel{$a->rel}連接自己';
$string['logs'] = '傳輸日誌';
$string['logsummary'] = '之前成功的傳輸';
$string['manageportfolios'] = '管理文件包';
$string['manageyourportfolios'] = '管理您的文件包';
$string['mimecheckfail'] = '這學習歷程外掛程式 {$a->plugin} 不支援 {$a->mimetype}類型';
$string['missingcallbackarg'] = '缺少呼叫類別{$a->class}的所需參數 {$a->arg}';
$string['moderatedbsizethreshold'] = '轉移時適度的資料庫大小';
$string['moderatedbsizethresholddesc'] = '資料庫紀錄的數目，超過這數目將花較多時間來傳送';
$string['moderatefilesizethreshold'] = '中度傳輸文件大小';
$string['moderatefilesizethresholddesc'] = '大小超過此閾值的文件會被視爲將消耗中度傳輸時間';
$string['multipleinstancesdisallowed'] = '試圖使用不支援多個實體的外掛程式建立多個實體（{$a}）';
$string['mustsetcallbackoptions'] = '您必須在 portfolio_add_button 的建構子或使用 set_callback_options 的方法設定呼叫選項';
$string['noavailableplugins'] = '抱歉，沒有您可用的文件包，無法導出';
$string['nocallbackclass'] = '找不到可呼叫的類別（{$a}）';
$string['nocallbackfile'] = '您正試圖從中會出的模組有些問題-找不到要求的檔案({$a})';
$string['noclassbeforeformats'] = '您在乎叫 portfolio_button 的 set_formats之前必須設定呼叫類別';
$string['nocommonformats'] = '被呼叫的 {$a->location} 和可用的學習歷程外掛程式之接沒有共同支援的格式(被呼叫的支援{$a->formates}）';
$string['noinstanceyet'] = '還沒有被選擇';
$string['nologs'] = '沒有日誌檔可以顯示!';
$string['nomultipleexports'] = '抱歉，目標歷程平台({$a->plugin}）不支援同時進行多個匯出。請<a href="{$a->link}">先完成目前的工作</a>再重新嘗試';
$string['nonprimative'] = '傳送到 portfolio_add_button的呼叫參數不是原始值。無法繼續。參數的key是{$a->key}，值是 {$a->value}';
$string['nopermissions'] = '抱歉，但是你沒有權限從這一區域匯出檔案。';
$string['notexportable'] = '抱歉，你試著要匯出的內容的類型，是不可匯出的。';
$string['notimplemented'] = '抱歉，您要匯出的格式還尚未實做（{$a}）';
$string['notyetselected'] = '還沒有被選擇';
$string['notyours'] = '你正試著還原一個學習歷程的匯出檔，但它不是屬於你的。';
$string['nouploaddirectory'] = '無法建立一暫時目錄來打包你的資料';
$string['off'] = '啟用但隱藏';
$string['on'] = '啟用且可看見';
$string['plugin'] = 'portfolio插件';
$string['plugincouldnotpackage'] = '為匯出而打包您的資料時出錯：原始錯誤是{$a}';
$string['pluginismisconfigured'] = '學習歷程外掛設定錯誤，跳過。錯誤是：{$a}';
$string['portfolio'] = '學習歷程';
$string['portfolios'] = '文件包';
$string['queuesummary'] = '當前排隊的轉移';
$string['returntowhereyouwere'] = '回到你原來的地方';
$string['save'] = '保存';
$string['selectedformat'] = '選擇匯出格式';
$string['selectedwait'] = '選出來等待？';
$string['selectplugin'] = '選擇目的地';
$string['singleinstancenomultiallowed'] = '只有一個可用的學習歷程外掛程式實體，它不支援每個工作階段多次匯出，並且已經有一個處於活動狀態的匯出正在該插件的工作階段中！';
$string['somepluginsdisabled'] = '有些學習歷程外掛程式整個被關閉，因為它們若不是設定錯誤，就是倚賴其他東西，它是：';
$string['sure'] = '你確定要刪除"{$a}"？這動作無法復原。';
$string['thirdpartyexception'] = '學習歷程匯出時擲出了一個第三方異常（{$a}）。已經捕捉到並重新拋出，但這個一定要修復';
$string['transfertime'] = '轉移時間';
$string['unknownplugin'] = '不知道(也許也許曾經有過，但被管理員移除)';
$string['wait'] = '等待';
$string['wanttowait_high'] = '不建議你等待這個轉移完成，但是若你確定且知道你在做什麼，你可以等下去。';
$string['wanttowait_moderate'] = '你是否要等待這一轉移？它可能要花好幾分鐘。';
