<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   enrol
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actenrolshhdr'] = '可用的選課插件';
$string['addinstance'] = '新增方式';
$string['ajaxnext25'] = '下25筆...';
$string['ajaxoneuserfound'] = '找到１個使用者';
$string['ajaxxusersfound'] = '找到{$a} 個使用者';
$string['assignnotpermitted'] = '您沒有這門課的角色控制權限';
$string['configenrolplugins'] = '請選擇所需要的插件，然後作適當的順序安排。';
$string['custominstancename'] = '自訂實體名稱';
$string['defaultenrol'] = '增加實體到新的課程';
$string['defaultenrol_desc'] = '加入這個插件預設會加入到所有的新的課程';
$string['deleteinstanceconfirm'] = '您確定要刪除選課插件實體"{$a->name}" 包含{$a->users}位已經選課的使用者？';
$string['durationdays'] = '{$a}天';
$string['enrol'] = '選修';
$string['enrolcandidates'] = '沒有選修使用者';
$string['enrolcandidatesmatching'] = '沒有符合的選修使用者';
$string['enrolcohort'] = '選修群組';
$string['enrolcohortusers'] = '加入使用者到這門課';
$string['enrollednewusers'] = '成功加入 {$a} 位使用者選課';
$string['enrolledusers'] = '已經選修的使用者';
$string['enrolledusersmatching'] = '符合的選修使用者';
$string['enrolme'] = '將我加入此課程';
$string['enrolmentinstances'] = '報名方式';
$string['enrolmentnew'] = '{$a}中新註冊的';
$string['enrolmentnewuser'] = '{$a->user}已經註冊"{$a->course}"這個課程';
$string['enrolmentoptions'] = '報名選項';
$string['enrolments'] = '選課方式';
$string['enrolnotpermitted'] = '您沒有權限加入使用者到這門課程中';
$string['enrolperiod'] = '修課期限';
$string['enroltimeend'] = '報名截止';
$string['enroltimestart'] = '報名開始';
$string['enrolusage'] = '實體/報名';
$string['enrolusers'] = '報名的使用者';
$string['errajaxfailedenrol'] = '無法登記使用者';
$string['errajaxsearch'] = '當搜尋使用者的時候發生錯誤';
$string['errorenrolcohort'] = '在此課程中建立群組同步選課實體出錯。';
$string['errorenrolcohortusers'] = '這門課的選課清單成員有錯誤。';
$string['extremovedaction'] = '外部取消選課動作';
$string['extremovedaction_help'] = '請選擇，當外部炫可來源的使用者消失時應該如何對應。請注意，在撤銷選課過程中，一些使用者資料和設定會被清除。';
$string['extremovedkeep'] = '保留已經報名使用者';
$string['extremovedsuspend'] = '取消課程報名';
$string['extremovedsuspendnoroles'] = '取消課程報名及刪除角色';
$string['extremovedunenrol'] = '取消使用者選課';
$string['finishenrollingusers'] = '完成報名的使用者';
$string['invalidenrolinstance'] = '無效的選課實體';
$string['invalidrole'] = '無效的角色';
$string['manageenrols'] = '管理選課模組';
$string['manageinstance'] = '管理';
$string['noexistingparticipants'] = '不存在任何的參與者';
$string['noguestaccess'] = '訪客無法進入這門課程，請登入。';
$string['none'] = '無';
$string['notenrollable'] = '您不能自行選修這門課';
$string['notenrolledusers'] = '其他使用者';
$string['otheruserdesc'] = '以下使用者不參加本課程，但確實有被分配角色，繼承或分配內。';
$string['participationactive'] = '活動';
$string['participationstatus'] = '狀態';
$string['participationsuspended'] = '暫停';
$string['periodend'] = '到 {$a}';
$string['periodstart'] = '從 {$a}';
$string['periodstartend'] = '從{$a->start} 到{$a->end}';
$string['recovergrades'] = '如果可能的話還原使用者舊的分數';
$string['rolefromcategory'] = '{$a->role}(從課程類別繼承)';
$string['rolefrommetacourse'] = '{$a->role}(從父課程繼承)';
$string['rolefromsystem'] = '{$a->role}（網站等級的分配）';
$string['rolefromthiscourse'] = '{$a->role} (分配到這門課程)';
$string['startdatetoday'] = '今日';
$string['synced'] = '資料已經同步';
$string['totalenrolledusers'] = '{$a}位已經報名的使用者';
$string['totalotherusers'] = '{$a}位其他使用者';
$string['unassignnotpermitted'] = '您沒有權限在這門課中分配角色';
$string['unenrol'] = '退出課程';
$string['unenrolconfirm'] = '您確定要退選使用者 "{$a->user}" 從課程 "{$a->course}"?';
$string['unenrolme'] = '我要退選{$a}';
$string['unenrolnotpermitted'] = '您沒有權限或是無法將該使用者從這門課退選';
$string['unenrolroleusers'] = '沒註冊的用戶';
$string['uninstallconfirm'] = '您正要完全刪除模組\' \'{$a}\'。這會完全刪除一切在資料庫的相關的內容，您確定要"繼續"此操作嗎？';
$string['uninstalldeletefiles'] = '與選課插件“{$a->plugin}”有關的所有資料都已經從資料庫刪除。要徹底完整刪除（防止此插件自己重新安裝），您要馬上在伺服器上刪除此目錄：{$a->directory}';
$string['unknowajaxaction'] = '未知的活動要求';
$string['unlimitedduration'] = '沒有限制';
$string['usersearch'] = '搜尋';
