<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_numerical', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   qtype_numerical
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addmoreanswerblanks'] = '增加 {no} 個答案';
$string['addmoreunitblanks'] = '再增加 {no} 個單位';
$string['answermustbenumberorstar'] = '答案必須是數字或是 \' * \'。';
$string['answerno'] = '答案 {$a}';
$string['errornomultiplier'] = '您必須指定這個單位的乘數。';
$string['errorrepeatedunit'] = '不能有兩個相同名稱的單位。';
$string['noneditableunittext'] = '單位1沒有可編輯的文字';
$string['nonvalidcharactersinnumber'] = '在數字中沒有有效的字元';
$string['notenoughanswers'] = '您必須至少輸入一個答案。';
$string['nounitdisplay'] = '沒有顯示單位';
$string['numericalmultiplier'] = '乘數';
$string['numericalmultiplier_help'] = '乘數是用來乘以答案，以進行單位換算用的。

單位1的預設乘數是1。因此如果正確的數值答案答案是 5500，而你在單位1設定 W 做為單位，那麼正確答案是5500W。

如果你在單位2加上一個新單位 kW，而乘數為 0.001，這表示另一個正確答案是 5.5kW。

注意，可接受的誤差也 需要換算，因此允許誤差如果是100W，那換算成另一個單位就是 0.1kW。';
$string['selectunit'] = '選擇一個單位';
$string['selectunits'] = '選擇單位';
$string['unitappliedpenalty'] = '這些分數包含單位錯誤的扣分 {$a}';
$string['unitedit'] = '編輯單位';
$string['unithdr'] = '單位 {$a}';
$string['unitmandatory'] = '強制的';
$string['unitmandatory_help'] = '*答案將會依據寫出的單位來評分。

*若單位欄是空白的，將會使用單位錯誤扣分。';
$string['unitoptional'] = '可選用的單位';
$string['unitoptional_help'] = '*若單位欄位不是空白的，這回答將會以這單位來計分。

*單位是錯誤或不明的，這回答將會視為無效。';
$string['unitpenalty'] = '單位錯誤扣分';
$string['validnumberformats'] = '有效數值格式';
