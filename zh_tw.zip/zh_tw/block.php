<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   block
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addtodock'] = '移到停靠欄';
$string['anypagematchingtheabove'] = '任何符合上麵條件的頁面';
$string['appearsinsubcontexts'] = '出現在子上下文';
$string['blocksettings'] = '版塊設置';
$string['bracketfirst'] = '{$a}（最高）';
$string['bracketlast'] = '{$a}（最低）';
$string['contexts'] = '頁面工作場景';
$string['defaultregion'] = '缺省區域';
$string['defaultweight'] = '缺省重量';
$string['moveblockhere'] = '移動版塊到此';
$string['movingthisblockcancel'] = '正在移動版塊（{$a}）';
$string['onthispage'] = '在本頁';
$string['pagetypes'] = '網頁類型';
$string['region'] = '區域';
$string['restrictpagetypes'] = '只限此種類型頁面';
$string['showoncontextandsubs'] = '顯示在“{$a}”及其子頁面';
$string['showoncontextonly'] = '只在“{$a}”裏顯示';
$string['showonentiresite'] = '在全站都可以使用';
$string['showonfrontpageandsubs'] = '顯示在首頁和所有添加到首頁的頁面中';
$string['showonfrontpageonly'] = '只顯示在首頁';
$string['subpages'] = '具體的子頁面';
$string['thisspecificpage'] = '就是此頁（頁面{$a}）';
$string['undockall'] = '移走全部';
$string['undockitem'] = '移走此項';
$string['visible'] = '可見';
$string['weight'] = '重量';
$string['wherethisblockappears'] = '此版塊顯示在哪裏';
