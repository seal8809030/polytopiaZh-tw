<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'webservice', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   webservice
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accessexception'] = '控制訪問的例外';
$string['accessnotallowed'] = '不允許瀏覽網站服務';
$string['actwebserviceshhdr'] = '可用的網站服務協定';
$string['addaservice'] = '新增服務';
$string['addcapabilitytousers'] = '檢查用戶權限';
$string['addcapabilitytousersdescription'] = '用戶需要有兩種權限----
*webservice:createtoken (建立通行憑證)
*配合傳輸協定的權限，例如
webservice/rest:use, webservice/soap:use 。

授予權限的方法是，由管理員建立一網上服務角色，包含以上兩種權限，並像系統角色一樣，把它指派給網上服務的用戶。';
$string['addfunction'] = '添加功能';
$string['addfunctionhelp'] = '選擇一功能來新增到這一服務。';
$string['addfunctions'] = '添加功能';
$string['addfunctionsdescription'] = '為這新建立的服務選擇必要的功能。';
$string['addrequiredcapability'] = '指派/取消指派 必要的權限';
$string['addservice'] = '增加一新服務：{$a->name} (id: {$a->id})';
$string['addservicefunction'] = '增加功能到這服務"{$a}"';
$string['allusers'] = '所有用戶';
$string['amftestclient'] = 'AMF測試用戶';
$string['apiexplorer'] = 'API探索器';
$string['apiexplorernotavalaible'] = 'API探索器還無法使用';
$string['arguments'] = '參數';
$string['authmethod'] = '認證方法';
$string['checkusercapability'] = '檢查用戶權限';
$string['checkusercapabilitydescription'] = '使用者應該有與使用的協議相匹配的權限，例如webservice/rest:use、webservice/soap:use。要分配這些權限，可以建立一個擁有這些權限的網路服務角色，並將它作為系統角色分配給網路服務用戶。';
$string['configwebserviceplugins'] = '為保障安全，應該只啟用使用中的協定。';
$string['context'] = '場景';
$string['createservicedescription'] = '服務室網路服務函數的集合。您將允許此使用者訪文一個新的服務。在<strong>加入新服務</strong>頁面勾選"啟用"只"服務授權使用者"選項。選擇"沒有需要的權限"。';
$string['createserviceforusersdescription'] = '服務是網路服務函式的集合。您將允許使用者瀏覽一個新的服務。在<strong>加入服務</strong>頁面勾選"啟用"，不勾選"只服務授權使用者"選項。選擇"沒有需要的權限"。';
$string['createtoken'] = '建立通行憑證';
$string['createtokenforuser'] = '為一用戶建立通行憑證';
$string['createtokenforuserdescription'] = '為這 web服務的用戶建立通行憑證';
$string['createuser'] = '創建一個特定的用戶';
$string['createuserdescription'] = '需要一個網路服務用戶來代表系統控制Moodle。';
$string['default'] = '默認成"{$a}"';
$string['deleteaservice'] = '刪除服務';
$string['deleteservice'] = '刪除這服務： {$a->name} (id: {$a->id})';
$string['deleteserviceconfirm'] = '刪除一服務也將刪除與這服務相關的通行憑證。你真的要刪除外部服務{$a}？';
$string['deletetokenconfirm'] = '你真的要刪除<strong>{$a->user}</strong> 在服務 <strong>{$a->service}</strong>上的網上服務通行憑證？';
$string['disabledwarning'] = '所有網路服務協定都被停用。在進階功能中有"啟用網路服務"選項。';
$string['doc'] = '文檔';
$string['docaccessrefused'] = '您未被允許察看此通行憑證文件';
$string['documentation'] = '網上服務文件';
$string['editaservice'] = '編輯服務';
$string['editservice'] = '編輯這服務 {$a->name} (id: {$a->id})';
$string['enabled'] = '啓用';
$string['enabledocumentation'] = '啟用開發者文件';
$string['enabledocumentationdescription'] = '啟用傳輸協定後，可以使用詳細的網上服務文件。';
$string['enableprotocols'] = '啟用傳輸協定';
$string['enableprotocolsdescription'] = '至少啟用一個協定。為了保障安全，應該只啟用要使用的協定。';
$string['enablews'] = '啟用web服務';
$string['enablewsdescription'] = '網上服務必須在進階功能中啟用。';
$string['entertoken'] = '輸入一安全密鑰';
$string['error'] = '錯誤：{$a}';
$string['errorcatcontextnotvalid'] = '您不能在類別場景(類別id：{$a->catid}）中執行函數。場景的錯誤訊息是：{$a->message}';
$string['errorcodes'] = '錯誤信息';
$string['errorcoursecontextnotvalid'] = '您不能在課程場景(課程id：{$a->courseid})中執行函數。場景錯誤資訊是：{$a->message}';
$string['errorinvalidparam'] = '這參數"{$a}"是無效的';
$string['errorinvalidparamsapi'] = '無效的外部api參數';
$string['errorinvalidparamsdesc'] = '無效的外部api參數';
$string['errorinvalidresponseapi'] = '無效的外部api回應';
$string['errorinvalidresponsedesc'] = '無效的外部api回應描述';
$string['errormissingkey'] = '在單個結構中缺少必須要的key：{$a}';
$string['errornotemptydefaultparamarray'] = '名為“{$a}”的網路服務描述參數是一個或多個結構。預設值只能是空陣列。請檢查網路服務敘述。';
$string['erroronlyarray'] = '只接受陣列。';
$string['erroroptionalparamarray'] = '名為“{$a}”的網路服務描述參數是一個或多個結構。它不能被設定為VALUE_OPTIONAL。請檢查網路服務描述。';
$string['errorresponsemissingkey'] = '回應中出現錯誤-在單個結構中缺少下列必須的key：{$a}';
$string['errorscalartype'] = '需要Scalar類型，但收到陣列或是物件。';
$string['errorunexpectedkey'] = '在參數組中偵測到不需要的key({$a})';
$string['execute'] = '執行';
$string['executewarnign'] = '警告：如果您點了執行按鈕，您的資料庫會被修改，並且不能自動恢復這些變更！';
$string['externalservice'] = '外部服務';
$string['externalservicefunctions'] = '外部服務功能';
$string['externalservices'] = '外部服務';
$string['externalserviceusers'] = '外部服務用戶';
$string['failedtolog'] = '無法建立日誌';
$string['forbiddenwsuser'] = '無法為一個沒被認證的、被刪除的、被停權的、或訪客用戶建立通行憑證。';
$string['function'] = '功能';
$string['functions'] = '函數';
$string['generalstructure'] = '一般結構';
$string['information'] = '信息';
$string['invalidextparam'] = '無效的外部API參數：{$a}';
$string['invalidextresponse'] = '無效的外部API反應：{$a}';
$string['invalidiptoken'] = '無效的通行憑證 -- 你的IP不被支援';
$string['invalidtimedtoken'] = '無效的通行憑證 -- 通行憑證過期';
$string['invalidtoken'] = '無效的通行憑證 -- 找不到通行憑證';
$string['invalidtokensession'] = '無效的工作階段基於通行憑證-找不到通行憑證或已經過其';
$string['iprestriction'] = 'IP限制';
$string['iprestriction_help'] = '用戶將需要從列表中的IP位址呼叫web服務';
$string['key'] = '密鑰';
$string['keyshelp'] = '這密鑰是用來從外部應用程式存取你的Moodle。';
$string['manageprotocols'] = '管理傳輸協定';
$string['managetokens'] = '管理通行憑證';
$string['missingcaps'] = '少了權限';
$string['missingcaps_help'] = '以下列表是被選出用戶要使用這服務時，需要有而卻沒有的權限。缺少的權限必須加到這用戶的角色，才能使用這服務。';
$string['missingpassword'] = '少了密碼';
$string['missingusername'] = '少了用戶名稱';
$string['nofunctions'] = '這一服務沒有功能。';
$string['norequiredcapability'] = '沒有需要的權限';
$string['notoken'] = '這令牌清單是空白的';
$string['operation'] = '操作';
$string['optional'] = '可選';
$string['phpparam'] = 'XML-RPC (PHP 結構)';
$string['phpresponse'] = 'XML-RPC (PHP 結構)';
$string['postrestparam'] = 'REST(POST request)的PHP程式碼';
$string['potusers'] = '沒有已經認證的用戶';
$string['potusersmatching'] = '沒有已經認證的用戶符合';
$string['print'] = '全部打印';
$string['protocol'] = '傳輸協定';
$string['removefunction'] = '刪除';
$string['removefunctionconfirm'] = '您確定要從服務“{$a->service}”刪除功能“{$a->function}”嗎？';
$string['requireauthentication'] = '此方法需要使用xxx權限認證。';
$string['required'] = '要求';
$string['requiredcapability'] = '需要的權限';
$string['requiredcapability_help'] = '如果設定，只有對應權限的使用者才能瀏覽此服務。';
$string['requiredcaps'] = '需要的權限';
$string['resettokenconfirm'] = '您確定要重置<strong>{$a->user}</strong>的<strong>{$a->service}</strong>服務網路服務密鑰嗎？';
$string['resettokenconfirmsimple'] = '您想重置這個密鑰嗎？所有使用舊密鑰的鏈接都將失效。';
$string['response'] = '反應';
$string['restcode'] = 'REST';
$string['restexception'] = 'REST';
$string['restparam'] = 'REST( POST參數)';
$string['restrictedusers'] = '只限於認證過的用戶';
$string['restrictedusers_help'] = '使用者可以在它們的安全密鑰頁面為此服務建立令牌。此設定決定是所有權現創建網路服務令牌的使用者都可以這樣做，還是只有被授權的使用者可以。';
$string['securitykey'] = '安全密鑰(通行憑證)';
$string['securitykeys'] = '安全密鑰';
$string['selectauthorisedusers'] = '選擇已經授權的用戶';
$string['selectedcapability'] = '選出的';
$string['selectedcapabilitydoesntexit'] = '目前設定的被必備權限({$a})已經不再存在。請修改並且儲存。';
$string['selectservice'] = '選擇一種服務';
$string['selectspecificuser'] = '選擇一特定的用戶';
$string['selectspecificuserdescription'] = '新增這網上服務的用戶，如同已經認證的用戶';
$string['service'] = '服務';
$string['servicehelpexplanation'] = '服務是一個函數組合。可以讓所有人獲只讓指定的使用者瀏覽服務。';
$string['servicename'] = '服務名稱';
$string['servicesbuiltin'] = '內建的服務';
$string['servicescustom'] = '自訂的服務';
$string['serviceusers'] = '授權的用戶';
$string['serviceusersettings'] = '用戶設置';
$string['serviceusersmatching'] = '授權用戶匹配';
$string['serviceuserssettings'] = '為已經被授權的用戶更改設定';
$string['simpleauthlog'] = '簡單認證登入';
$string['step'] = '步驟';
$string['testauserwithtestclientdescription'] = '用網路服務測試客戶端模擬外部瀏覽。
在開始之前，先要用有moodle/webservice:createtoken權限的使用者並通過我的個人資料設定獲得密鑰(token)。您將在測試客戶端使用此令牌。在測試客戶端中，用令牌認證選擇一個已經啟用的協定。<strong>警告：您測試的函數會被真的執行，所以小心選擇測試什麼！</strong>';
$string['testclient'] = '網上服務測試客戶';
$string['testclientdescription'] = '*此網路服務測試客戶端會<strong>真的執行</strong>被測試函數。不要測試您不了解的函數。<br />
*此測試客戶端並沒有實現所有的網路服務<br />
*您可以透過測試一些停用的函數來檢查使用者是否能訪問它們。<br />
*要看到更清楚的錯誤訊息，到"“{$a->atag}”頁面把調整狀太設為<strong>{$a->mode}</strong><br />
*瀏覽 {$a->amfatag}。';
$string['testwithtestclient'] = '測試服務';
$string['testwithtestclientdescription'] = '用網路服務測試客戶端模擬外部瀏覽。用令牌(token)認證，使用一個已經啟用的協定。<strong>警告L：您測試的函數會被真的執行，所以小心選擇測試什麼！</strong>';
$string['token'] = '通行憑證';
$string['tokenauthlog'] = '通行憑證的認證';
$string['tokencreatedbyadmin'] = '只能由管理員重置 (*)';
$string['tokencreator'] = '建立者';
$string['updateusersettings'] = '更新';
$string['userasclients'] = '用戶為有通行憑證的客戶';
$string['userasclientsdescription'] = '下面步驟幫助您面向使用者設定Moodle的網路服務。這些步驟也幫助您設定建議採用的令牌(安全密鑰）認證方法。在這種情況下，使用者可以在我的個人資料設定中的安全密鑰頁面產生它的令牌。';
$string['usermissingcaps'] = '缺少權限：{$a}';
$string['usernotallowed'] = '此使用者無法使用此服務。首先，您需要在{$a}的許可使用者管理頁面允此使用者使用。';
$string['usersettingssaved'] = '用戶設置已保存';
$string['validuntil'] = '有效期至';
$string['validuntil_help'] = '若設定，這服務在這一日期之後，會對此用戶關閉。';
$string['webservice'] = 'Web服務';
$string['webservices'] = 'Web服務';
$string['webservicesoverview'] = '概述';
$string['webservicetokens'] = '網上服務令牌';
$string['wrongusernamepassword'] = '錯誤的名稱或密碼';
$string['wsaccessuserdeleted'] = '拒絕網上服務的存取，因為使用已被刪除的用戶名稱：{$a}';
$string['wsaccessuserexpired'] = '拒絕網上服務的存取，因為密碼已經過期，用戶名稱：{$a}';
$string['wsaccessusernologin'] = '拒絕網上服務的存取，因為沒有登入認證，用戶名稱：{$a}';
$string['wsaccessusersuspended'] = '拒絕網上服務的存取，因為被停權，用戶名稱：{$a}';
$string['wsaccessuserunconfirmed'] = '拒絕網上服務的存取，因為沒被確認，用戶名稱：{$a}';
$string['wsauthmissing'] = '缺少網路服務認證外掛程式。';
$string['wsauthnotenabled'] = '缺少網路服務認證外掛程式。';
$string['wsclientdoc'] = 'Moodle 網上服務客戶文件';
$string['wsdocapi'] = 'API文件';
$string['wsdocumentation'] = '網上服務文檔';
$string['wsdocumentationdisable'] = '網上服務文檔被關閉';
$string['wsdocumentationintro'] = '要建立客戶，我們建議你先讀這文件{$a->doclink}';
$string['wsdocumentationlogin'] = '或輸入你的網上際服務用戶名稱和密碼：';
$string['wspassword'] = '網上服務密碼';
$string['wsusername'] = '網上服務用戶名稱';
