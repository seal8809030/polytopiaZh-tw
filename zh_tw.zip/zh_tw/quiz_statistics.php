<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'quiz_statistics', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   quiz_statistics
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allattempts'] = '所有試答';
$string['allattemptsavg'] = '所有試答的平均分';
$string['allattemptscount'] = '試答總數';
$string['analysisofresponses'] = '試題分析';
$string['analysisofresponsesfor'] = '{$a}的試題分析';
$string['attempts'] = '試答';
$string['attemptsall'] = '所有試答';
$string['attemptsfirst'] = '首次試答';
$string['backtoquizreport'] = '返回到統計報告主頁。';
$string['calculatefrom'] = '統計數據來自';
$string['cic'] = '內部一致性係數（{$a}）';
$string['count'] = '次數';
$string['coursename'] = '課程名';
$string['detailedanalysis'] = '此題的更詳細的作答分析';
$string['discrimination_index'] = '辨識度指數';
$string['discriminative_efficiency'] = '辨識效果';
$string['downloadeverything'] = '下載完整報告爲';
$string['duration'] = '開放期間';
$string['effective_weight'] = '實際權重';
$string['errordeleting'] = '刪除舊的 {$a}筆紀錄時發生錯誤';
$string['erroritemappearsmorethanoncewithdifferentweight'] = '同一試題({$a})在這測驗的不同位置以不同的加權量出現，這在此統計報告上並不支援，且也會使該題目的統計量不切實際。';
$string['errormedian'] = '在取中位數時，發生錯誤';
$string['errorpowerquestions'] = '取資料計算試題分數的變異量時，發生錯誤';
$string['errorpowers'] = '取資料計算測驗分數的變異量時，發生錯誤';
$string['errorrandom'] = '取試題資料時發生錯誤';
$string['errorratio'] = '錯誤率（{$a}）';
$string['errorstatisticsquestions'] = '取資料計算試題分數的統計量時發生錯誤';
$string['facility'] = '容易度指數';
$string['firstattempts'] = '首次試答';
$string['firstattemptsavg'] = '首次試答平均分';
$string['firstattemptscount'] = '首次試答個數';
$string['frequency'] = '次數分配';
$string['intended_weight'] = '預期權重';
$string['kurtosis'] = '分數分佈峰度（{$a}）';
$string['lastcalculated'] = '{$a->lastcalculated}之前最後一次計算。此後又有{$a->count}個試答。';
$string['median'] = '成績中值（{$a}）';
$string['negcovar'] = '試題得分與測驗總分成負相關';
$string['negcovar_help'] = '在試題分析時，若某一題目的得分與整份測驗的總分呈負相關(能力高的在該題答錯機率較高，能力低的反而答對機率較高)，它就是一種試題鑑別度為負的，應該刪除的不良試題。

此模組的效率試題加權(effective question weight)計算公式無法處理這種案例。

遇到這種情形，你可以重新編輯測驗卷，把該鑑別力為負的題目的配分(最大分數)改為零分，再重新計分即可。';
$string['nostudentsingroup'] = '此小組中還沒有學生';
$string['optiongrade'] = '部分得分';
$string['position'] = '題號';
$string['positions'] = '位置';
$string['questioninformation'] = '試題資訊';
$string['questionname'] = '題目名';
$string['questionnumber'] = '題#';
$string['questionstatistics'] = '題目統計';
$string['questiontype'] = '題目類型';
$string['quizinformation'] = '測驗信息';
$string['quizname'] = '測驗名';
$string['quizoverallstatistics'] = '測驗整體統計';
$string['quizstructureanalysis'] = '測驗結構分析';
$string['random_guess_score'] = '隨機猜測分數';
$string['recalculatenow'] = '立即重新計算';
$string['skewness'] = '分數分佈偏度（{$a}）';
$string['standarddeviation'] = '標準偏差（{$a}）';
$string['standarddeviationq'] = '標準偏差';
$string['standarderror'] = '標準錯誤（{$a}）';
$string['statistics'] = '統計';
$string['statistics:componentname'] = '測驗的統計報告';
$string['statisticsreport'] = '統計報告';
$string['statisticsreportgraph'] = '每題統計';
$string['statistics:view'] = '查看統計報表';
$string['statsfor'] = '{$a}測驗的統計報告';
