<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'data', language 'zh_tw', branch 'MOODLE_20_STABLE'
 *
 * @package   data
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action'] = '操作';
$string['add'] = '新增資料';
$string['addcomment'] = '新增評論';
$string['addentries'] = '新增資料';
$string['addtemplate'] = '新增樣板';
$string['advancedsearch'] = '進階搜尋';
$string['alttext'] = '替代文字';
$string['approve'] = '核准';
$string['approved'] = '已批准的';
$string['ascending'] = '升冪';
$string['asearchtemplate'] = '進階搜尋的樣板';
$string['atmaxentry'] = '您輸入的資料量已經超過達到上限！';
$string['authorfirstname'] = '作者的名字';
$string['authorlastname'] = '作者的姓氏';
$string['autogenallforms'] = '產生所有預設樣板';
$string['autolinkurl'] = '自動連結網址';
$string['availablefromdate'] = '活動開始時間';
$string['availabletags'] = '可用的標籤';
$string['availabletags_help'] = '標籤是模組裡面的占位符號。當項目被編輯或顯示時，它們會被替換為資料或物件。

欄位會使用格式[[fieldname]]
其它的標籤使用##sometag##</p>
只有在"可用的標籤"列表中出現的標籤才能被目前的模組使用。';
$string['availabletodate'] = '活動結束時間';
$string['blank'] = '空白';
$string['buttons'] = '按鈕';
$string['bynameondate'] = '{$a->name} - {$a->date}';
$string['cancel'] = '取消';
$string['cannotaccesspresentsother'] = '您不被允許瀏覽其他其他使用者的預先設定';
$string['cannotadd'] = '無法增加新的項目！';
$string['cannotdeletepreset'] = '刪除預設時出現錯誤！';
$string['cannotunziptopreset'] = '無法解壓縮到預設資料夾';
$string['checkbox'] = '核選方塊';
$string['chooseexportfields'] = '選擇您想要匯出的欄位：';
$string['chooseexportformat'] = '選擇您想要匯出的格式：';
$string['chooseorupload'] = '選擇檔案';
$string['columns'] = '欄位';
$string['comment'] = '評論';
$string['commentdeleted'] = '評論刪除了';
$string['commentempty'] = '評論是空白的';
$string['comments'] = '評論';
$string['commentsaved'] = '評論儲存了';
$string['commentsn'] = '{$a}個評論';
$string['commentsoff'] = '尚未啟用回應功能';
$string['configenablerssfeeds'] = '這個項目可以啟用所有資料庫的 RSS 資料供應，您必須在個別資料庫中手動啟用。';
$string['confirmdeletefield'] = '您確定要刪除這個欄位？';
$string['confirmdeleterecord'] = '您確定要刪除這筆資料？';
$string['csstemplate'] = 'CSS 樣板';
$string['csvfailed'] = '無法從CSV 檔案中抓取原始資料';
$string['csvfile'] = 'CSV 檔案';
$string['csvimport'] = '匯入 CSV 檔案';
$string['csvimport_help'] = '可以從純文字檔匯入資料。這個檔案的第一行是欄位名稱，然後每行是一條紀錄。';
$string['csvwithselecteddelimiter'] = '<acronym title="Comma Separated Values">CSV</acronym> 文字採用的分隔符號：';
$string['data:approve'] = '審核未批准的資料';
$string['data:comment'] = '撰寫評論';
$string['data:exportallentries'] = '匯出所有資料庫項目';
$string['data:exportentry'] = '匯出一條資料庫項目';
$string['data:exportownentry'] = '匯出自己的資料庫項目';
$string['data:managecomments'] = '管理評論';
$string['data:manageentries'] = '管理資料';
$string['data:managetemplates'] = '管理樣板';
$string['data:manageuserpresets'] = '管理所有樣板預設值';
$string['data:rate'] = '評比資料';
$string['data:readentry'] = '讀取資料';
$string['data:viewallratings'] = '瀏覽所有人送出的原始評等';
$string['data:viewalluserpresets'] = '從所有使用者檢視預設值';
$string['data:viewanyrating'] = '瀏覽每個人得到的總評等';
$string['data:viewentry'] = '檢視資料';
$string['data:viewrating'] = '檢視評比';
$string['data:writeentry'] = '撰寫資料';
$string['date'] = '日期';
$string['dateentered'] = '輸入日期';
$string['defaultfielddelimiter'] = '（預設是逗點字元）';
$string['defaultfieldenclosure'] = '（預設為無）';
$string['defaultsortfield'] = '預設排序欄位';
$string['delete'] = '刪除';
$string['deleteallentries'] = '刪除所有條目';
$string['deletecomment'] = '您確定要刪除這個評論';
$string['deleted'] = '已刪除';
$string['deletefield'] = '刪除現有欄位';
$string['deletenotenrolled'] = '刪除未選課者的條目';
$string['deletewarning'] = '您確定要刪除這個預設值？';
$string['descending'] = '降冪';
$string['directorynotapreset'] = '{$a->directory} 不是預設：缺少檔案： {$a->missing_files}';
$string['download'] = '下載';
$string['edit'] = '編輯';
$string['editcomment'] = '編輯評論';
$string['editentry'] = '編輯資料';
$string['editordisable'] = '停用編輯器';
$string['editorenable'] = '啟用編輯器';
$string['emptyadd'] = '新增樣板為空白，從預設格式產生...';
$string['emptyaddform'] = '您沒有填入任何欄位！';
$string['entries'] = '資料';
$string['entrieslefttoadd'] = '在您瀏覽其他參與者條目前，您必須增加{$a->entriesleft}更多條目。';
$string['entrieslefttoaddtoview'] = '您必須新增{$a->entrieslefttoview}筆以上資料，才能夠看到其他同學提供的資料。';
$string['entry'] = '資料';
$string['entrysaved'] = '您的資料已經儲存了';
$string['errormustbeteacher'] = '只有教師身份可以使用這個頁面！';
$string['errorpresetexists'] = '選擇的名稱已經有人使用';
$string['example'] = '資料庫模組範例';
$string['excel'] = 'Excel';
$string['expired'] = '對不起，這項活動截止於{$a}，不再有效';
$string['export'] = '匯出';
$string['exportaszip'] = '匯出成zip壓縮格式';
$string['exportaszip_help'] = '<p align="center"><strong>以zip格式匯出</strong></p>
<p>允許將模版下載到您自己的電腦上，然後模版可以上傳到一個不同的資料庫中使用。
</p>';
$string['exportedtozip'] = '匯出成暫存的zip壓縮檔...';
$string['exportentries'] = '匯出項目';
$string['exportownentries'] = '匯出您自己的項目？（{$a->mine}/{$a->all}）';
$string['failedpresetdelete'] = '刪除預設值時發生錯誤！';
$string['fieldadded'] = '欄位新增了';
$string['fieldallowautolink'] = '允許自動連結';
$string['fielddeleted'] = '欄位刪除了';
$string['fielddelimiter'] = '欄位分隔字元';
$string['fielddescription'] = '欄位說明';
$string['fieldenclosure'] = '欄位附件';
$string['fieldheight'] = '高度';
$string['fieldheightlistview'] = '列表高度';
$string['fieldheightsingleview'] = '單筆資料高度';
$string['fieldids'] = '欄位編號';
$string['fieldmappings'] = '欄位對應';
$string['fieldmappings_help'] = '此選單將資料和已經存在的資料庫分離。為了保存某個欄位中的資料，您需要將該欄位對應到一個新的欄位，資料會儲存到新的欄位中。留空白的欄位不會複製任何資料。任何未對應到新欄位的舊欄位和它的資料都會被刪除。您只可以對應同一類型的欄位，所以每個下拉框框中有不同的欄位。而且，必須注意，必要將同一個舊的欄位對應到多個新欄位中。';
$string['fieldname'] = '欄位名稱';
$string['fieldnotmatched'] = '您檔案中的下列欄位不存在資料庫中：{$a}';
$string['fieldoptions'] = '選項（每行一個）';
$string['fields'] = '欄位';
$string['fieldupdated'] = '欄位更新了';
$string['fieldwidth'] = '寬度';
$string['fieldwidthlistview'] = '列表寬度';
$string['fieldwidthsingleview'] = '單筆資料寬度';
$string['file'] = '檔案';
$string['filesnotgenerated'] = '並非所有檔案都是產生的： {$a}';
$string['filtername'] = '資料庫自動連結';
$string['footer'] = '頁尾';
$string['forcelinkname'] = '強制為連結取名';
$string['foundnorecords'] = '沒有記錄資料 (<a href="<b>{$a->reseturl}</b>">重設篩選器</a>)';
$string['foundrecords'] = '找到記錄資料： <b>{$a->num}</b>/<b>{$a->max}</b> (<a href="<b>{$a->reseturl}</b>">重設篩選器</a>)';
$string['fromfile'] = '從 zip 壓縮檔案匯入';
$string['fromfile_help'] = '從ZIP檔案匯入允許您瀏覽以及上傳包含預先設定的模版欄位之ZIP檔';
$string['generateerror'] = '有部分檔案沒有產生！';
$string['header'] = '頁首';
$string['headeraddtemplate'] = '定義編輯資料的介面';
$string['headerasearchtemplate'] = '訂定進階搜尋的介面';
$string['headercsstemplate'] = '定義其他樣板的本地端 CSS 風格';
$string['headerjstemplate'] = '為其他樣板自訂 Javascript';
$string['headerlisttemplate'] = '定義多筆資料的瀏覽介面';
$string['headerrsstemplate'] = '定義 RSS 資料顯示方式';
$string['headersingletemplate'] = '定義檢視單筆資料介面';
$string['importentries'] = '匯入項目';
$string['importsuccess'] = '成功套用預設值。';
$string['insufficiententries'] = '需要輸入更多資料才能檢視這個資料庫';
$string['intro'] = '簡介';
$string['invalidaccess'] = '頁面瀏覽錯誤';
$string['invalidfieldid'] = '欄位ID錯誤';
$string['invalidfieldname'] = '請選擇另一個欄位名稱';
$string['invalidfieldtype'] = '欄位類型錯誤';
$string['invalidid'] = '不正確的資料ID';
$string['invalidpreset'] = '{$a}不是一個預設。';
$string['invalidrecord'] = '不正確的紀錄';
$string['invalidurl'] = '輸入的網址無效';
$string['jstemplate'] = 'Javascript樣板';
$string['latitude'] = '緯度';
$string['latlong'] = '緯度/經度';
$string['latlongdownloadallhint'] = '把所有的資料連結下載為KML文件';
$string['latlongkmllabelling'] = '怎樣在KML文件中標出內容（Google Earth）';
$string['latlonglinkservicesdisplayed'] = '連結外部服務來顯示';
$string['latlongotherfields'] = '其他欄位';
$string['list'] = '檢視清單';
$string['listtemplate'] = '列出樣板';
$string['longitude'] = '經度';
$string['mapexistingfield'] = '對應到 {$a}';
$string['mapnewfield'] = '建立一個新欄位';
$string['mappingwarning'] = '所有沒對應新欄位的舊欄位將會遺失，其中的資料也會移除。';
$string['maxentries'] = '資料量上限';
$string['maxentries_help'] = '學生在此活動可以送出的最大項目數量。';
$string['maxsize'] = '資料大小上限';
$string['menu'] = '選單';
$string['menuchoose'] = '選擇...';
$string['missingdata'] = '需要提供資料ID或是目標給欄位類別。';
$string['missingfield'] = '程式錯誤：您需要在定義欄位類別時指定欄位或資料。';
$string['modulename'] = '資料庫';
$string['modulename_help'] = '資料庫活動模組允許參與者建立、維護和搜尋一組記錄項目。這些項目的格式和結構幾乎是沒有限制的，可以包含圖片、文字、超連結、數字以及純文字等各種格式。';
$string['modulenameplural'] = '資料庫';
$string['more'] = '更多';
$string['moreurl'] = '更多網址';
$string['movezipfailed'] = '無法搬移 zip 檔';
$string['multientry'] = '重複性資料';
$string['multimenu'] = '選單（多選）';
$string['multipletags'] = '找到多個標籤！樣板未儲存';
$string['namecheckbox'] = '核選方塊欄位';
$string['namedate'] = '日期欄位';
$string['namefile'] = '檔案欄位';
$string['namelatlong'] = '緯度/經度欄位';
$string['namemenu'] = '選單欄位';
$string['namemultimenu'] = '多重選單欄位';
$string['namenumber'] = '數字欄位';
$string['namepicture'] = '圖片欄位';
$string['nameradiobutton'] = '單選欄位';
$string['nametext'] = '文字欄位';
$string['nametextarea'] = '多行文字欄位';
$string['nameurl'] = '網址欄位';
$string['newentry'] = '新增資料';
$string['newfield'] = '建立新欄位';
$string['newfield_help'] = '欄位允許資料輸入。每個在資料庫活動的項目能能夠包含多個項目以及多種格式，像是一個資料欄位能使用下拉式選單選擇日期月份以及年份，一個圖片欄位允許上傳一張圖檔，或是核取方塊欄位允許使用者單選或是複選。

每個欄位只能擁有唯一的欄位名稱。欄位敘述則是可以選擇要不要填。';
$string['noaccess'] = '您沒有存取這個頁面的權限';
$string['nodefinedfields'] = '新預設值沒有定義欄位！';
$string['nofieldcontent'] = '找不到欄位內容';
$string['nofieldindatabase'] = '目前這個資料庫沒有定義任何欄位。';
$string['nolisttemplate'] = '樣板列表尚未定義';
$string['nomatch'] = '找不到符合的資料！';
$string['nomaximum'] = '沒有上限';
$string['norecords'] = '沒有資料';
$string['nosingletemplate'] = '尚未定義單一樣版';
$string['notapproved'] = '項目尚未被核准。';
$string['notinjectivemap'] = '不是一個可插入的地圖';
$string['notopenyet'] = '抱歉，此活動直到{$a}才可以使用';
$string['number'] = '數量';
$string['numberrssarticles'] = 'RSS 文章';
$string['numnotapproved'] = '等待中';
$string['numrecords'] = '{$a} 筆資料';
$string['ods'] = '<acronym title="OpenDocument Spreadsheet">ODS</acronym> (OpenOffice)';
$string['optionaldescription'] = '簡述（選）';
$string['optionalfilename'] = '檔名（選）';
$string['other'] = '其他';
$string['overrwritedesc'] = '如果預設設定已經存在則覆寫它';
$string['overwrite'] = '覆蓋';
$string['overwritesettings'] = '覆蓋現在的設定';
$string['pagesize'] = '每頁顯示資料量';
$string['participants'] = '參與者';
$string['picture'] = '圖片';
$string['pleaseaddsome'] = '請在下面建立一些欄位或是<a href="{$a}">選擇一個預先定義的集合</a>，再開始。';
$string['pluginadministration'] = '資料庫活動管理';
$string['pluginname'] = '資料庫';
$string['portfolionotfile'] = '匯出到學習歷程而非檔案（只支援csv格式和leap2a格式）';
$string['presetinfo'] = '儲存為預設值將會發佈這個樣板。其他使用者可以在他們的資料庫中使用它。';
$string['presets'] = '預設值';
$string['radiobutton'] = '單選按鈕';
$string['recordapproved'] = '資料核准了';
$string['recorddeleted'] = '資料刪除了';
$string['recordsnotsaved'] = '沒有資料儲存，請檢查上傳檔案的格式。';
$string['recordssaved'] = '資料儲存了';
$string['requireapproval'] = '請求審核？';
$string['requireapproval_help'] = '如果啟用，項目必須在老師核准後才能被其他人觀看。';
$string['requiredentries'] = '必要資料';
$string['requiredentries_help'] = '必須要完成的項目數量。這個數目可以要求學生必須要完成的項目數量，可以用來定義完成進度。';
$string['requiredentriestoview'] = '檢視前需要的基本資料量';
$string['requiredentriestoview_help'] = '每一學生需要提交該數量的條目之後，才可以看到其他學生的條目。

注意：若要先寫條目才可檢閱他人條目，那資料庫的自動鏈結應該關閉。這是因為資料庫自動連結過濾器無法確認用戶是否有提交足夠數量的條目。';
$string['resetsettings'] = '重設欄位';
$string['resettemplate'] = '重設樣板';
$string['resizingimages'] = '調整縮圖大小...';
$string['rows'] = '列';
$string['rssglobaldisabled'] = '停用，檢視網站設定變數。';
$string['rsshowmany'] = '（新資料顯示數量，0 表示停用 RSS）';
$string['rsstemplate'] = 'RSS樣板';
$string['rsstitletemplate'] = 'RSS標題樣板';
$string['save'] = '儲存';
$string['saveandadd'] = '儲存後新增';
$string['saveandview'] = '儲存後檢視';
$string['saveaspreset'] = '儲存為預設值';
$string['saveaspreset_help'] = '儲存為預設值功能會發佈此模版和欄位，網站中的其他人也可以使用。（您隨時可以將其從預設列表中刪除。）';
$string['savesettings'] = '儲存設定';
$string['savesuccess'] = '儲存成功，您的預設值現在開始可以在網站使用。';
$string['savetemplate'] = '儲存樣板';
$string['search'] = '搜尋';
$string['selectedrequired'] = '所有必要的選擇';
$string['showall'] = '顯示所有資料';
$string['single'] = '檢視單筆';
$string['singletemplate'] = '單一樣版';
$string['teachersandstudents'] = '{$a->teachers} 與 {$a->students}';
$string['templates'] = '樣板';
$string['templatesaved'] = '樣板儲存了';
$string['text'] = '文字';
$string['textarea'] = '多行文字';
$string['timeadded'] = '新增的時間';
$string['timemodified'] = '修改的時間';
$string['todatabase'] = '到此資料庫。';
$string['type'] = '欄位類型';
$string['undefinedprocessactionmethod'] = '在 Data_Preset 沒有定義動作方法來處理動作 "{$a}"。';
$string['unsupportedexport'] = '(<b>{$a->fieldtype}</b>) 無法匯出。';
$string['updatefield'] = '更新現有欄位';
$string['uploadfile'] = '上傳檔案';
$string['uploadrecords'] = '從檔案上傳資料';
$string['uploadrecords_help'] = '可以透過上傳純文字檔案來更新項目。檔案的格式如向

*文件每行包含一項資料
*每個資料一系列由逗點（或其他符號）分隔的資料
*第一條記錄包含一串用來定義文件其他部分格式的欄位名稱

欄位圍繞符號是一個包圍每個記錄中的每個欄位的符號。通常可以不對它進行設定';
$string['url'] = '網址';
$string['usestandard'] = '使用一個預設值';
$string['usestandard_help'] = '請在列表中選擇要使用的預設值。（對於您使用"另存為預設值"加入到列表中的預設值，會顯示刪除選項）';
$string['viewfromdate'] = '開始只能閱讀';
$string['viewtodate'] = '結束只能閱讀';
$string['wrongdataid'] = '提供的資料編號有誤';
